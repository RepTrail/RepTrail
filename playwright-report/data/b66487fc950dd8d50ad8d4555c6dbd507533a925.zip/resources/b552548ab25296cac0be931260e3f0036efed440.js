(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_pra usar dps_6 - Pessoal_RepTrail_web_src_components_80800798._.js",
  "static/chunks/2c0c8_52da778c._.js"
],
    source: "dynamic"
});
