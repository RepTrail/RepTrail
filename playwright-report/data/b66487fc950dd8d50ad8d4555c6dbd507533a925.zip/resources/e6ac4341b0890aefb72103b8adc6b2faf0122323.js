(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/2c0c8_e4bcd95b._.js",
  "static/chunks/Desktop_pra usar dps_6 - Pessoal_RepTrail_web_src_components_5adff30a._.js"
],
    source: "dynamic"
});
