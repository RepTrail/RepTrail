(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/2c0c8_e4bcd95b._.js",
  "static/chunks/Desktop_pra usar dps_6 - Pessoal_RepTrail_web_src_components_5adff30a._.js",
  "static/chunks/f115e_6 - Pessoal_RepTrail_web_src_components_feature_pwa-install-prompt_tsx_cafd3d5f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);