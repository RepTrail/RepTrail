(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toast",
    ()=>Toast,
    "ToastAction",
    ()=>ToastAction,
    "ToastClose",
    ()=>ToastClose,
    "ToastDescription",
    ()=>ToastDescription,
    "ToastProvider",
    ()=>ToastProvider,
    "ToastTitle",
    ()=>ToastTitle,
    "ToastViewport",
    ()=>ToastViewport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@radix-ui/react-toast/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const ToastProvider = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Provider"];
const ToastViewport = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("fixed top-0 z-[100] flex max-h-screen w-full flex-col-reverse p-4 sm:bottom-0 sm:right-0 sm:top-auto sm:flex-col md:max-w-[420px]", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c1 = ToastViewport;
ToastViewport.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Viewport"].displayName;
const toastVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("group pointer-events-auto relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-6 pr-8 shadow-lg transition-all data-[swipe=cancel]:translate-x-0 data-[swipe=end]:translate-x-[var(--radix-toast-swipe-end-x)] data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)] data-[swipe=move]:transition-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[swipe=end]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:slide-out-to-right-full data-[state=open]:slide-in-from-top-full data-[state=open]:sm:slide-in-from-bottom-full", {
    variants: {
        variant: {
            default: "border bg-background text-foreground",
            destructive: "destructive group border-destructive bg-destructive text-destructive-foreground"
        }
    },
    defaultVariants: {
        variant: "default"
    }
});
const Toast = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c2 = ({ className, variant, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(toastVariants({
            variant
        }), className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
        lineNumber: 48,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
});
_c3 = Toast;
Toast.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Root"].displayName;
const ToastAction = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c4 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex h-8 shrink-0 items-center justify-center rounded-md border bg-transparent px-3 text-sm font-medium ring-offset-background transition-colors hover:bg-secondary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 group-[.destructive]:border-muted/40 group-[.destructive]:hover:border-destructive/30 group-[.destructive]:hover:bg-destructive group-[.destructive]:hover:text-destructive-foreground group-[.destructive]:focus:ring-destructive", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c5 = ToastAction;
ToastAction.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Action"].displayName;
const ToastClose = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c6 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Close"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("absolute right-2 top-2 rounded-md p-1 text-foreground/50 opacity-0 transition-opacity hover:text-foreground focus:opacity-100 focus:outline-none focus:ring-2 group-hover:opacity-100 group-[.destructive]:text-red-300 group-[.destructive]:hover:text-red-50 group-[.destructive]:focus:ring-red-400 group-[.destructive]:focus:ring-offset-red-600", className),
        "toast-close": "",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
            className: "h-4 w-4"
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
            lineNumber: 85,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c7 = ToastClose;
ToastClose.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Close"].displayName;
const ToastTitle = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c8 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm font-semibold", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
        lineNumber: 94,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c9 = ToastTitle;
ToastTitle.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Title"].displayName;
const ToastDescription = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](_c10 = ({ className, ...props }, ref)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"], {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm opacity-90", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx",
        lineNumber: 106,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0)));
_c11 = ToastDescription;
ToastDescription.displayName = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Description"].displayName;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
__turbopack_context__.k.register(_c, "ToastViewport$React.forwardRef");
__turbopack_context__.k.register(_c1, "ToastViewport");
__turbopack_context__.k.register(_c2, "Toast$React.forwardRef");
__turbopack_context__.k.register(_c3, "Toast");
__turbopack_context__.k.register(_c4, "ToastAction$React.forwardRef");
__turbopack_context__.k.register(_c5, "ToastAction");
__turbopack_context__.k.register(_c6, "ToastClose$React.forwardRef");
__turbopack_context__.k.register(_c7, "ToastClose");
__turbopack_context__.k.register(_c8, "ToastTitle$React.forwardRef");
__turbopack_context__.k.register(_c9, "ToastTitle");
__turbopack_context__.k.register(_c10, "ToastDescription$React.forwardRef");
__turbopack_context__.k.register(_c11, "ToastDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/hooks/use-toast.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "reducer",
    ()=>reducer,
    "toast",
    ()=>toast,
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
const TOAST_LIMIT = 1;
const TOAST_REMOVE_DELAY = 1000000;
const actionTypes = {
    ADD_TOAST: "ADD_TOAST",
    UPDATE_TOAST: "UPDATE_TOAST",
    DISMISS_TOAST: "DISMISS_TOAST",
    REMOVE_TOAST: "REMOVE_TOAST"
};
let count = 0;
function genId() {
    count = (count + 1) % Number.MAX_SAFE_INTEGER;
    return count.toString();
}
const toastTimeouts = new Map();
const addToRemoveQueue = (toastId)=>{
    if (toastTimeouts.has(toastId)) {
        return;
    }
    const timeout = setTimeout(()=>{
        toastTimeouts.delete(toastId);
        dispatch({
            type: "REMOVE_TOAST",
            toastId
        });
    }, TOAST_REMOVE_DELAY);
    toastTimeouts.set(toastId, timeout);
};
const reducer = (state, action)=>{
    switch(action.type){
        case "ADD_TOAST":
            return {
                ...state,
                toasts: [
                    action.toast,
                    ...state.toasts
                ].slice(0, TOAST_LIMIT)
            };
        case "UPDATE_TOAST":
            return {
                ...state,
                toasts: state.toasts.map((t)=>t.id === action.toast.id ? {
                        ...t,
                        ...action.toast
                    } : t)
            };
        case "DISMISS_TOAST":
            {
                const { toastId } = action;
                // ! Side effects ! - This could be extracted into a dismissToast() action,
                // but I'll keep it here for simplicity
                if (toastId) {
                    addToRemoveQueue(toastId);
                } else {
                    state.toasts.forEach((toast)=>{
                        addToRemoveQueue(toast.id);
                    });
                }
                return {
                    ...state,
                    toasts: state.toasts.map((t)=>t.id === toastId || toastId === undefined ? {
                            ...t,
                            open: false
                        } : t)
                };
            }
        case "REMOVE_TOAST":
            if (action.toastId === undefined) {
                return {
                    ...state,
                    toasts: []
                };
            }
            return {
                ...state,
                toasts: state.toasts.filter((t)=>t.id !== action.toastId)
            };
    }
};
const listeners = [];
let memoryState = {
    toasts: []
};
function dispatch(action) {
    memoryState = reducer(memoryState, action);
    listeners.forEach((listener)=>{
        listener(memoryState);
    });
}
function toast({ ...props }) {
    const id = genId();
    const update = (props)=>dispatch({
            type: "UPDATE_TOAST",
            toast: {
                ...props,
                id
            }
        });
    const dismiss = ()=>dispatch({
            type: "DISMISS_TOAST",
            toastId: id
        });
    dispatch({
        type: "ADD_TOAST",
        toast: {
            ...props,
            id,
            open: true,
            onOpenChange: (open)=>{
                if (!open) dismiss();
            }
        }
    });
    return {
        id,
        dismiss,
        update
    };
}
function useToast() {
    _s();
    const [state, setState] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](memoryState);
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useToast.useEffect": ()=>{
            listeners.push(setState);
            return ({
                "useToast.useEffect": ()=>{
                    const index = listeners.indexOf(setState);
                    if (index > -1) {
                        listeners.splice(index, 1);
                    }
                }
            })["useToast.useEffect"];
        }
    }["useToast.useEffect"], [
        state
    ]);
    return {
        ...state,
        toast,
        dismiss: (toastId)=>dispatch({
                type: "DISMISS_TOAST",
                toastId
            })
    };
}
_s(useToast, "SPWE98mLGnlsnNfIwu/IAKTSZtk=");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Toaster",
    ()=>Toaster
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/hooks/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function Toaster() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(6);
    if ($[0] !== "1b7550444943a36b601118a1f1465b868010655234408d2ec31b9fb44af6236e") {
        for(let $i = 0; $i < 6; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "1b7550444943a36b601118a1f1465b868010655234408d2ec31b9fb44af6236e";
    }
    const { toasts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    let t0;
    if ($[1] !== toasts) {
        t0 = toasts.map(_ToasterToastsMap);
        $[1] = toasts;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    let t1;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastViewport"], {}, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
            lineNumber: 27,
            columnNumber: 10
        }, this);
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    let t2;
    if ($[4] !== t0) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastProvider"], {
            children: [
                t0,
                t1
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
            lineNumber: 34,
            columnNumber: 10
        }, this);
        $[4] = t0;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    return t2;
}
_s(Toaster, "temIROJu2YfngpcEVM4UFtRVIvg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = Toaster;
function _ToasterToastsMap(t0) {
    const { id, title, description, action, ...props } = t0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Toast"], {
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-1",
                children: [
                    title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastTitle"], {
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
                        lineNumber: 50,
                        columnNumber: 75
                    }, this),
                    description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastDescription"], {
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
                        lineNumber: 50,
                        columnNumber: 124
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
                lineNumber: 50,
                columnNumber: 37
            }, this),
            action,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$toast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ToastClose"], {}, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
                lineNumber: 50,
                columnNumber: 189
            }, this)
        ]
    }, id, true, {
        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/toaster.tsx",
        lineNumber: 50,
        columnNumber: 10
    }, this);
}
var _c;
__turbopack_context__.k.register(_c, "Toaster");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/supabase/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@supabase/ssr/dist/module/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://xubjlkztymdaggikvzsu.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh1Ympsa3p0eW1kYWdnaWt2enN1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEyODU5MDMsImV4cCI6MjA4Njg2MTkwM30.CWgeiRIGrpCYdGcxK6npcv3PP3RkRC3Cz4Bpwr7DRFA"));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/notifications.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "registerServiceWorker",
    ()=>registerServiceWorker,
    "subscribeToPush",
    ()=>subscribeToPush
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/supabase/client.ts [app-client] (ecmascript)");
;
async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('/sw.js', {
                scope: '/'
            });
            return registration;
        } catch (error) {
            console.error('Service Worker registration failed:', error);
        }
    }
}
async function subscribeToPush() {
    const registration = await navigator.serviceWorker.ready;
    // You need to replace this with your actual VAPID public key
    const publicVapidKey = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
    if (!publicVapidKey) {
        console.error('VAPID public key not found in environment variables');
        return;
    }
    try {
        const subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(publicVapidKey)
        });
        const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$supabase$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
            await supabase.from('push_subscriptions').upsert({
                user_id: user.id,
                subscription: subscription,
                updated_at: new Date().toISOString()
            }, {
                onConflict: 'user_id'
            });
        }
        return subscription;
    } catch (error) {
        console.error('Push subscription failed:', error);
    }
}
function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for(let i = 0; i < rawData.length; ++i){
        outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/pwa-client.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PWAClient",
    ()=>PWAClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/notifications.ts [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const PWAInstallPrompt = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript, next/dynamic entry, async loader)").then((mod)=>mod.PWAInstallPrompt), {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = PWAInstallPrompt;
function PWAClient() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(3);
    if ($[0] !== "de149cd8ba5955bef5e276454f69b9f984fc8d66b6a679231af8aa0cbf7d37fb") {
        for(let $i = 0; $i < 3; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "de149cd8ba5955bef5e276454f69b9f984fc8d66b6a679231af8aa0cbf7d37fb";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(_PWAClientUseEffect, t0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PWAInstallPrompt, {}, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/pwa-client.tsx",
            lineNumber: 28,
            columnNumber: 10
        }, this);
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    return t1;
}
_s(PWAClient, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c1 = PWAClient;
function _PWAClientUseEffect() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$notifications$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerServiceWorker"])();
}
var _c, _c1;
__turbopack_context__.k.register(_c, "PWAInstallPrompt");
__turbopack_context__.k.register(_c1, "PWAClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/force-reload.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ForceReload",
    ()=>ForceReload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
const APP_VERSION = 'v1.0.1'; // Change this string to bust cache and force reload
function ForceReload() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(2);
    if ($[0] !== "bdf5e41a4b798c95e7dd11c25695ea9eeaa47dc6e5c65d9bf800b7224f0c39cf") {
        for(let $i = 0; $i < 2; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bdf5e41a4b798c95e7dd11c25695ea9eeaa47dc6e5c65d9bf800b7224f0c39cf";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(_ForceReloadUseEffect, t0);
    return null;
}
_s(ForceReload, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ForceReload;
function _ForceReloadUseEffect() {
    const storedVersion = localStorage.getItem("app-version");
    if (storedVersion !== APP_VERSION) {
        localStorage.setItem("app-version", APP_VERSION);
        window.location.reload();
    }
}
var _c;
__turbopack_context__.k.register(_c, "ForceReload");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SplashScreen",
    ()=>SplashScreen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function SplashScreen(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "790c098d598b1343a1de9139cbb74b7b2b9f3542ab0c1f1caa13507d8ea24a5c") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "790c098d598b1343a1de9139cbb74b7b2b9f3542ab0c1f1caa13507d8ea24a5c";
    }
    const { onFinish, redirectHref } = t0;
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [isFinishing, setIsFinishing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    let t1;
    let t2;
    if ($[1] !== onFinish || $[2] !== redirectHref || $[3] !== router) {
        t1 = ({
            "SplashScreen[useEffect()]": ()=>{
                const finishTimer = setTimeout({
                    "SplashScreen[useEffect() > setTimeout()]": ()=>{
                        setIsFinishing(true);
                        setTimeout({
                            "SplashScreen[useEffect() > setTimeout() > setTimeout()]": ()=>{
                                setIsVisible(false);
                                setTimeout({
                                    "SplashScreen[useEffect() > setTimeout() > setTimeout() > setTimeout()]": ()=>{
                                        if (onFinish) {
                                            onFinish();
                                        }
                                        if (redirectHref) {
                                            router.push(redirectHref);
                                        }
                                    }
                                }["SplashScreen[useEffect() > setTimeout() > setTimeout() > setTimeout()]"], 400);
                            }
                        }["SplashScreen[useEffect() > setTimeout() > setTimeout()]"], 500);
                    }
                }["SplashScreen[useEffect() > setTimeout()]"], 1500);
                return ()=>clearTimeout(finishTimer);
            }
        })["SplashScreen[useEffect()]"];
        t2 = [
            onFinish,
            redirectHref,
            router
        ];
        $[1] = onFinish;
        $[2] = redirectHref;
        $[3] = router;
        $[4] = t1;
        $[5] = t2;
    } else {
        t1 = $[4];
        t2 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (!isVisible) {
        return null;
    }
    const t3 = `fixed inset-0 z-[9999] flex items-center justify-center bg-black transition-opacity duration-700 ${isVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`;
    let t4;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
            children: "\n                @keyframes saber-draw {\n                    from { stroke-dashoffset: 100; }\n                    to { stroke-dashoffset: 0; }\n                }\n\n                .rt-minimal-bolt {\n                    stroke-dasharray: 100;\n                    stroke-dashoffset: 100;\n                    animation: saber-draw 1.5s cubic-bezier(0.65, 0, 0.35, 1) forwards;\n                    stroke-linecap: round;\n                    stroke-linejoin: round;\n                    will-change: stroke-dashoffset;\n                }\n\n                .rt-finish-fade {\n                    animation: bolt-fade-out 0.5s ease-in forwards;\n                }\n\n                @keyframes bolt-fade-out {\n                    to { opacity: 0; transform: scale(0.95); }\n                }\n            "
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx",
            lineNumber: 70,
            columnNumber: 10
        }, this);
        $[6] = t4;
    } else {
        t4 = $[6];
    }
    const t5 = `relative w-24 h-24 flex items-center justify-center transition-all duration-500 ${isFinishing ? "rt-finish-fade" : ""}`;
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "0 0 24 24",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg",
            className: "w-full h-full",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
                stroke: "#ffffff",
                strokeWidth: "0.8",
                pathLength: "100",
                className: "rt-minimal-bolt",
                style: {
                    strokeDashoffset: 100,
                    strokeDasharray: 100
                }
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx",
                lineNumber: 78,
                columnNumber: 108
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== t5) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t5,
            children: t6
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx",
            lineNumber: 88,
            columnNumber: 10
        }, this);
        $[8] = t5;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] !== t3 || $[11] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t3,
            suppressHydrationWarning: true,
            children: [
                t4,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx",
            lineNumber: 96,
            columnNumber: 10
        }, this);
        $[10] = t3;
        $[11] = t7;
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    return t8;
}
_s(SplashScreen, "yOSDMeGhOLRqD83uV5Dnmj6k1VM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = SplashScreen;
var _c;
__turbopack_context__.k.register(_c, "SplashScreen");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/splash-manager.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SplashManager",
    ()=>SplashManager
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$feature$2f$shared$2f$splash$2d$screen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/shared/splash-screen.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function SplashManager(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(11);
    if ($[0] !== "fc00963750a227415b1b042dea6faed9a1e51ea7848594971e08745892e2b91f") {
        for(let $i = 0; $i < 11; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fc00963750a227415b1b042dea6faed9a1e51ea7848594971e08745892e2b91f";
    }
    const { children } = t0;
    const [view, setView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("none");
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "SplashManager[useEffect()]": ()=>{
                const isStandalone = ("TURBOPACK compile-time value", "object") !== "undefined" && window.matchMedia("(display-mode: standalone)").matches;
                const isPWAUrl = ("TURBOPACK compile-time value", "object") !== "undefined" && window.location.search.includes("source=pwa");
                const hasSeenSplash = ("TURBOPACK compile-time value", "object") !== "undefined" && sessionStorage.getItem("reptrail_splash_seen");
                if (isStandalone || isPWAUrl || !hasSeenSplash) {
                    setView("splash");
                    sessionStorage.setItem("reptrail_splash_seen", "true");
                } else {
                    setView("ready");
                }
            }
        })["SplashManager[useEffect()]"];
        t2 = [];
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    if (view === "none") {
        let t3;
        if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 bg-black z-[9999] pointer-events-none"
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/splash-manager.tsx",
                lineNumber: 48,
                columnNumber: 12
            }, this);
            $[3] = t3;
        } else {
            t3 = $[3];
        }
        let t4;
        if ($[4] !== children) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t3,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "opacity-0",
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/splash-manager.tsx",
                        lineNumber: 55,
                        columnNumber: 18
                    }, this)
                ]
            }, void 0, true);
            $[4] = children;
            $[5] = t4;
        } else {
            t4 = $[5];
        }
        return t4;
    }
    if (view === "splash") {
        let t3;
        if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
            t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$feature$2f$shared$2f$splash$2d$screen$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SplashScreen"], {
                onFinish: {
                    "SplashManager[<SplashScreen>.onFinish]": ()=>setView("ready")
                }["SplashManager[<SplashScreen>.onFinish]"]
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/layout/splash-manager.tsx",
                lineNumber: 66,
                columnNumber: 12
            }, this);
            $[6] = t3;
        } else {
            t3 = $[6];
        }
        let t4;
        if ($[7] !== children) {
            t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    t3,
                    children
                ]
            }, void 0, true);
            $[7] = children;
            $[8] = t4;
        } else {
            t4 = $[8];
        }
        return t4;
    }
    let t3;
    if ($[9] !== children) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: children
        }, void 0, false);
        $[9] = children;
        $[10] = t3;
    } else {
        t3 = $[10];
    }
    return t3;
}
_s(SplashManager, "ElFwIOmIWwVCLQMU/lQ2SyJXpco=");
_c = SplashManager;
var _c;
__turbopack_context__.k.register(_c, "SplashManager");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/actions/data:217b6a [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "impersonateUser",
    ()=>$$RSC_SERVER_ACTION_17
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"403f126e70d07cb4e0dd854db3cc364a6c66c0a011":"impersonateUser"},"Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/actions/admin-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("403f126e70d07cb4e0dd854db3cc364a6c66c0a011", __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "impersonateUser");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vYWRtaW4tYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHNlcnZlcidcblxuaW1wb3J0IHsgY3JlYXRlQ2xpZW50IH0gZnJvbSAnQC9saWIvc3VwYWJhc2Uvc2VydmVyJ1xuaW1wb3J0IHsgY3JlYXRlQWRtaW5DbGllbnQgfSBmcm9tICdAL2xpYi9zdXBhYmFzZS9hZG1pbidcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSAnbmV4dC9jYWNoZSdcbmltcG9ydCB7IGNvb2tpZXMgfSBmcm9tICduZXh0L2hlYWRlcnMnXG5pbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gJ25leHQvbmF2aWdhdGlvbidcblxuYXN5bmMgZnVuY3Rpb24gY2hlY2tBZG1pbigpIHtcbiAgICBjb25zdCBzdXBhYmFzZSA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpXG4gICAgY29uc3QgeyBkYXRhOiB7IHVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKClcbiAgICBpZiAoIXVzZXIpIHRocm93IG5ldyBFcnJvcignVW5hdXRob3JpemVkJylcbiAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Byb2ZpbGVzJykuc2VsZWN0KCdpc19hZG1pbicpLmVxKCdpZCcsIHVzZXIuaWQpLnNpbmdsZSgpXG4gICAgaWYgKCFwcm9maWxlPy5pc19hZG1pbikgdGhyb3cgbmV3IEVycm9yKCdVbmF1dGhvcml6ZWQnKVxuICAgIHJldHVybiB7IHN1cGFiYXNlLCB1c2VySWQ6IHVzZXIuaWQgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWRtaW5PdmVydmlldygpIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlIH0gPSBhd2FpdCBjaGVja0FkbWluKClcblxuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgY291bnQ6IHRvdGFsVHJhaW5lcnMgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Byb2ZpbGVzJykuc2VsZWN0KCcqJywgeyBjb3VudDogJ2V4YWN0JywgaGVhZDogdHJ1ZSB9KS5lcSgncm9sZScsICd0cmFpbmVyJylcbiAgICAgICAgY29uc3QgeyBjb3VudDogdG90YWxTdHVkZW50cyB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZmlsZXMnKS5zZWxlY3QoJyonLCB7IGNvdW50OiAnZXhhY3QnLCBoZWFkOiB0cnVlIH0pLmVxKCdyb2xlJywgJ3N0dWRlbnQnKVxuICAgICAgICBjb25zdCB7IGNvdW50OiB0b3RhbFJlbGF0aW9uc2hpcHMgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3RyYWluZXJfc3R1ZGVudHMnKS5zZWxlY3QoJyonLCB7IGNvdW50OiAnZXhhY3QnLCBoZWFkOiB0cnVlIH0pXG5cbiAgICAgICAgY29uc3QgeyBjb3VudDogY291bnRBZmZpbGlhdGVzIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdwcm9maWxlcycpLnNlbGVjdCgnKicsIHsgY291bnQ6ICdleGFjdCcsIGhlYWQ6IHRydWUgfSkuZXEoJ2lzX2FmZmlsaWF0ZScsIHRydWUpXG5cbiAgICAgICAgY29uc3QgeyBkYXRhOiBhZmZpbGlhdGVCYWxhbmNlcyB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZmlsZXMnKS5zZWxlY3QoJ2FmZmlsaWF0ZV9iYWxhbmNlJykuZXEoJ2lzX2FmZmlsaWF0ZScsIHRydWUpXG4gICAgICAgIGNvbnN0IGFmZmlsaWF0ZURlYnQgPSBhZmZpbGlhdGVCYWxhbmNlcz8ucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIChOdW1iZXIoY3Vyci5hZmZpbGlhdGVfYmFsYW5jZSkgfHwgMCksIDApIHx8IDBcblxuICAgICAgICAvLyBUcmFpbmVycyBTdWJzIFJldmVudWVcbiAgICAgICAgLy8gRmV0Y2ggYWxsIHRyYWluZXJzIHRvIGNoZWNrIHRoZWlyIHBsYW5zXG4gICAgICAgIC8vIEZldGNoIGFsbCB0cmFpbmVycyB0byBjaGVjayB0aGVpciBwbGFuc1xuICAgICAgICBjb25zdCB7IGRhdGE6IHRyYWluZXJzIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdwcm9maWxlcycpLnNlbGVjdCgnaWQsIHBsYW5fdGllciwgY3JlYXRlZF9hdCwgZWxpdGVfdW50aWwnKS5lcSgncm9sZScsICd0cmFpbmVyJylcblxuICAgICAgICAvLyBGZXRjaCBhbGwgYWN0aXZlIHN0dWRlbnRzIG1hcHBlZCB0byB0cmFpbmVycyB0byBjYWxjdWxhdGUgdXNhZ2VcbiAgICAgICAgY29uc3QgeyBkYXRhOiBhY3RpdmVTdHVkZW50cyB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhaW5lcl9zdHVkZW50cycpLnNlbGVjdCgndHJhaW5lcl9pZCcpLmVxKCdhY3RpdmUnLCB0cnVlKVxuXG4gICAgICAgIGNvbnN0IHRyYWluZXJTdHVkZW50Q291bnRzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge31cbiAgICAgICAgYWN0aXZlU3R1ZGVudHM/LmZvckVhY2gocyA9PiB7XG4gICAgICAgICAgICBpZiAocy50cmFpbmVyX2lkKSB0cmFpbmVyU3R1ZGVudENvdW50c1tzLnRyYWluZXJfaWRdID0gKHRyYWluZXJTdHVkZW50Q291bnRzW3MudHJhaW5lcl9pZF0gfHwgMCkgKyAxXG4gICAgICAgIH0pXG5cbiAgICAgICAgY29uc3QgcHJpY2VzOiBhbnkgPSB7IG9uX2RlbWFuZDogMCB9XG4gICAgICAgIGNvbnN0IHVzYWdlUnVsZXM6IGFueSA9IHsgb25fZGVtYW5kOiB7IGxpbWl0OiA1LCBwcmljZV9wZXJfZXh0cmE6IDEwLjkwIH0gfSAvLyBOZXcgbW9kZWw6IDEwLjkwIHBlciBzdHVkZW50ID4gNVxuXG4gICAgICAgIGxldCBtb250aGx5U3Vic1JldmVudWUgPSAwXG4gICAgICAgIGxldCB0b3RhbFN1YnNSZXZlbnVlID0gMFxuICAgICAgICBsZXQgdHJpYWxDb3VudCA9IDBcbiAgICAgICAgbGV0IHN0dWRlbnRzSW5UcmlhbCA9IDBcblxuICAgICAgICBjb25zb2xlLmxvZygnLS0tIEFkbWluIFJldmVudWUgQ2FsYyAtLS0nKVxuXG4gICAgICAgIHRyYWluZXJzPy5mb3JFYWNoKHQgPT4ge1xuICAgICAgICAgICAgLy8gQ2hlY2sgZm9yIGFjdGl2ZSB0cmlhbFxuICAgICAgICAgICAgY29uc3QgaXNUcmlhbEFjdGl2ZSA9IHQuZWxpdGVfdW50aWwgJiYgbmV3IERhdGUodC5lbGl0ZV91bnRpbCkgPiBuZXcgRGF0ZSgpXG5cbiAgICAgICAgICAgIC8vIElmIHRyaWFsIGlzIGFjdGl2ZSwgc3Vic2NyaXB0aW9uIHJldmVudWUgaXMgMFxuICAgICAgICAgICAgaWYgKGlzVHJpYWxBY3RpdmUpIHtcbiAgICAgICAgICAgICAgICB0cmlhbENvdW50KytcbiAgICAgICAgICAgICAgICBzdHVkZW50c0luVHJpYWwgKz0gKHRyYWluZXJTdHVkZW50Q291bnRzW3QuaWRdIHx8IDApXG4gICAgICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNvbnN0IHAgPSB0LnBsYW5fdGllciB8fCAnb25fZGVtYW5kJ1xuICAgICAgICAgICAgY29uc3QgZml4ZWRQcmljZSA9IHByaWNlc1twXSB8fCAwXG5cbiAgICAgICAgICAgIGxldCByZXZlbnVlID0gZml4ZWRQcmljZVxuXG4gICAgICAgICAgICAvLyBJZiBPbiBEZW1hbmQgKG9yIGFueSBwbGFuIG5vdyksIGFkZCB1c2FnZSBmZWVcbiAgICAgICAgICAgIGNvbnN0IGNvdW50ID0gdHJhaW5lclN0dWRlbnRDb3VudHNbdC5pZF0gfHwgMFxuICAgICAgICAgICAgY29uc3QgeyBsaW1pdCwgcHJpY2VfcGVyX2V4dHJhIH0gPSB1c2FnZVJ1bGVzLm9uX2RlbWFuZFxuICAgICAgICAgICAgaWYgKGNvdW50ID4gbGltaXQpIHtcbiAgICAgICAgICAgICAgICByZXZlbnVlICs9IChjb3VudCAtIGxpbWl0KSAqIHByaWNlX3Blcl9leHRyYVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBtb250aGx5U3Vic1JldmVudWUgKz0gcmV2ZW51ZVxuXG4gICAgICAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHQuY3JlYXRlZF9hdClcbiAgICAgICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcbiAgICAgICAgICAgIGNvbnN0IG1vbnRocyA9IE1hdGgubWF4KDEsIChub3cuZ2V0RnVsbFllYXIoKSAtIHN0YXJ0LmdldEZ1bGxZZWFyKCkpICogMTIgKyAobm93LmdldE1vbnRoKCkgLSBzdGFydC5nZXRNb250aCgpKSArIDEpXG4gICAgICAgICAgICB0b3RhbFN1YnNSZXZlbnVlICs9IChyZXZlbnVlICogbW9udGhzKVxuICAgICAgICB9KVxuXG4gICAgICAgIC8vIC0tLSBORVc6IFN0dWRlbnQgQXV0by1UcmFpbmluZyBSZXZlbnVlIC0tLVxuICAgICAgICBjb25zdCB7IGRhdGE6IGF1dG9UcmFpbmluZ1N0dWRlbnRzIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAgICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAgICAgICAgIC5zZWxlY3QoJ2lkLCBjcmVhdGVkX2F0JylcbiAgICAgICAgICAgIC5lcSgncm9sZScsICdzdHVkZW50JylcbiAgICAgICAgICAgIC5lcSgnYXV0b190cmFpbmluZ19zdGF0dXMnLCAnYWN0aXZlJylcblxuICAgICAgICBjb25zdCBzdHVkZW50QXV0b1RyYWluaW5nUHJpY2UgPSAxMC45MFxuICAgICAgICBjb25zdCBtb250aGx5U3R1ZGVudFJldmVudWUgPSAoYXV0b1RyYWluaW5nU3R1ZGVudHM/Lmxlbmd0aCB8fCAwKSAqIHN0dWRlbnRBdXRvVHJhaW5pbmdQcmljZVxuICAgICAgICBtb250aGx5U3Vic1JldmVudWUgKz0gbW9udGhseVN0dWRlbnRSZXZlbnVlXG5cbiAgICAgICAgYXV0b1RyYWluaW5nU3R1ZGVudHM/LmZvckVhY2gocyA9PiB7XG4gICAgICAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHMuY3JlYXRlZF9hdClcbiAgICAgICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcbiAgICAgICAgICAgIGNvbnN0IG1vbnRocyA9IE1hdGgubWF4KDEsIChub3cuZ2V0RnVsbFllYXIoKSAtIHN0YXJ0LmdldEZ1bGxZZWFyKCkpICogMTIgKyAobm93LmdldE1vbnRoKCkgLSBzdGFydC5nZXRNb250aCgpKSArIDEpXG4gICAgICAgICAgICB0b3RhbFN1YnNSZXZlbnVlICs9IChzdHVkZW50QXV0b1RyYWluaW5nUHJpY2UgKiBtb250aHMpXG4gICAgICAgIH0pXG5cbiAgICAgICAgLy8gVHJhaW5lciBWb2x1bWUgKFN0dWRlbnRzIHBheWluZyBUcmFpbmVycykgLSBKdXN0IHB1cmVseSB2b2x1bWUsIG5vIHRheCB0YWtlblxuICAgICAgICBjb25zdCB7IGRhdGE6IHN0dWRlbnRzRGF0YSB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgndHJhaW5lcl9zdHVkZW50cycpLnNlbGVjdCgnbW9udGhseV9mZWUsIGFjdGl2ZSwgY3JlYXRlZF9hdCcpXG5cbiAgICAgICAgY29uc3QgbW9udGhseVRyYWluZXJWb2x1bWUgPSBzdHVkZW50c0RhdGE/LnJlZHVjZSgoYWNjLCBjdXJyKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gY3Vyci5hY3RpdmUgPyBhY2MgKyAoTnVtYmVyKGN1cnIubW9udGhseV9mZWUpIHx8IDApIDogYWNjXG4gICAgICAgIH0sIDApIHx8IDBcblxuICAgICAgICBjb25zdCB0b3RhbFRyYWluZXJWb2x1bWUgPSBzdHVkZW50c0RhdGE/LnJlZHVjZSgoYWNjLCBjdXJyKSA9PiB7XG4gICAgICAgICAgICBpZiAoIWN1cnIuYWN0aXZlKSByZXR1cm4gYWNjXG4gICAgICAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKGN1cnIuY3JlYXRlZF9hdClcbiAgICAgICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcbiAgICAgICAgICAgIGNvbnN0IG1vbnRocyA9IE1hdGgubWF4KDEsIChub3cuZ2V0RnVsbFllYXIoKSAtIHN0YXJ0LmdldEZ1bGxZZWFyKCkpICogMTIgKyAobm93LmdldE1vbnRoKCkgLSBzdGFydC5nZXRNb250aCgpKSArIDEpXG4gICAgICAgICAgICByZXR1cm4gYWNjICsgKChOdW1iZXIoY3Vyci5tb250aGx5X2ZlZSkgfHwgMCkgKiBtb250aHMpXG4gICAgICAgIH0sIDApIHx8IDBcblxuXG4gICAgICAgIC8vIEFmZmlsaWF0ZSBNZXRyaWNzIChDYWxjdWxhdGVkIGVhcmx5IGZvciBOZXQgUHJvZml0KVxuICAgICAgICBjb25zdCB7IGRhdGE6IGFsbENvbW1pc3Npb25zIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdhZmZpbGlhdGVfY29tbWlzc2lvbnMnKS5zZWxlY3QoJ2Ftb3VudCwgY3JlYXRlZF9hdCwgc3RhdHVzJylcbiAgICAgICAgY29uc3QgYWZmaWxpYXRlVG90YWxFYXJuaW5ncyA9IGFsbENvbW1pc3Npb25zPy5yZWR1Y2UoKGFjYywgY3VycikgPT4gYWNjICsgKE51bWJlcihjdXJyLmFtb3VudCkgfHwgMCksIDApIHx8IDBcbiAgICAgICAgY29uc3QgY3VycmVudE1vbnRoU3RhcnQgPSBuZXcgRGF0ZSgpXG4gICAgICAgIGN1cnJlbnRNb250aFN0YXJ0LnNldERhdGUoMSlcbiAgICAgICAgY3VycmVudE1vbnRoU3RhcnQuc2V0SG91cnMoMCwgMCwgMCwgMClcbiAgICAgICAgY29uc3QgY29tbWlzc2lvbnNUaGlzTW9udGggPSBhbGxDb21taXNzaW9ucz8ucmVkdWNlKChhY2MsIGN1cnIpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZShjdXJyLmNyZWF0ZWRfYXQpXG4gICAgICAgICAgICBpZiAoZGF0ZSA+PSBjdXJyZW50TW9udGhTdGFydCAmJiBjdXJyLnN0YXR1cyAhPT0gJ2NhbmNlbGxlZCcpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWNjICsgKE51bWJlcihjdXJyLmFtb3VudCkgfHwgMClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBhY2NcbiAgICAgICAgfSwgMCkgfHwgMFxuICAgICAgICBjb25zdCBwZW5kaW5nQ29tbWlzc2lvbnMgPSBhbGxDb21taXNzaW9ucz8ucmVkdWNlKChhY2MsIGN1cnIpID0+IHtcbiAgICAgICAgICAgIGlmIChjdXJyLnN0YXR1cyA9PT0gJ3BlbmRpbmcnIHx8IGN1cnIuc3RhdHVzID09PSAnY29uZmlybWVkJykge1xuICAgICAgICAgICAgICAgIHJldHVybiBhY2MgKyAoTnVtYmVyKGN1cnIuYW1vdW50KSB8fCAwKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGFjY1xuICAgICAgICB9LCAwKSB8fCAwXG5cbiAgICAgICAgLy8gUGxhdGZvcm0gR3Jvc3MgUmV2ZW51ZSAoT25seSBTdWJzL1VzYWdlIFJldmVudWUpXG4gICAgICAgIGNvbnN0IG1vbnRobHlHcm9zc1JldmVudWUgPSBtb250aGx5U3Vic1JldmVudWVcbiAgICAgICAgY29uc3QgdG90YWxHcm9zc1JldmVudWUgPSB0b3RhbFN1YnNSZXZlbnVlXG5cbiAgICAgICAgLy8gT3BlcmF0aW9uYWwgQ29zdHNcbiAgICAgICAgY29uc3QgeyBkYXRhOiBhbGxDb3N0cyB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgnb3BlcmF0aW9uYWxfY29zdHMnKS5zZWxlY3QoJ2Ftb3VudCwgdHlwZSwgY3JlYXRlZF9hdCcpXG5cbiAgICAgICAgY29uc3QgdG90YWxPcGVyYXRpb25hbENvc3RzID0gYWxsQ29zdHM/LnJlZHVjZSgoYWNjLCBjdXJyKSA9PiBhY2MgKyAoTnVtYmVyKGN1cnIuYW1vdW50KSB8fCAwKSwgMCkgfHwgMFxuXG4gICAgICAgIGNvbnN0IG1vbnRobHlPcGVyYXRpb25hbENvc3RzID0gYWxsQ29zdHM/LnJlZHVjZSgoYWNjLCBjdXJyKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoY3Vyci5jcmVhdGVkX2F0KVxuICAgICAgICAgICAgaWYgKGRhdGUgPj0gY3VycmVudE1vbnRoU3RhcnQpIHJldHVybiBhY2MgKyAoTnVtYmVyKGN1cnIuYW1vdW50KSB8fCAwKVxuICAgICAgICAgICAgcmV0dXJuIGFjY1xuICAgICAgICB9LCAwKSB8fCAwXG5cbiAgICAgICAgLy8gTmV0IFByb2ZpdCBDYWxjdWxhdGlvblxuICAgICAgICAvLyBOZXQgPSBHcm9zcyBSZXZlbnVlIC0gQWZmaWxpYXRlIENvbW1pc3Npb25zIC0gT3BlcmF0aW9uYWwgQ29zdHNcbiAgICAgICAgY29uc3QgbW9udGhseU5ldFByb2ZpdCA9IG1vbnRobHlHcm9zc1JldmVudWUgLSBjb21taXNzaW9uc1RoaXNNb250aCAtIG1vbnRobHlPcGVyYXRpb25hbENvc3RzXG4gICAgICAgIGNvbnN0IHRvdGFsTmV0UHJvZml0ID0gdG90YWxHcm9zc1JldmVudWUgLSBhZmZpbGlhdGVUb3RhbEVhcm5pbmdzIC0gdG90YWxPcGVyYXRpb25hbENvc3RzXG5cbiAgICAgICAgY29uc3QgeyBjb3VudDogcHJvZHVjdENsaWNrcyB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZHVjdF9jbGlja3MnKS5zZWxlY3QoJyonLCB7IGNvdW50OiAnZXhhY3QnLCBoZWFkOiB0cnVlIH0pXG4gICAgICAgIGNvbnN0IHsgY291bnQ6IHRvdGFsUHJvZHVjdHMgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3N0b3JlX3Byb2R1Y3RzJykuc2VsZWN0KCcqJywgeyBjb3VudDogJ2V4YWN0JywgaGVhZDogdHJ1ZSB9KS5lcSgnaXNfYWN0aXZlJywgdHJ1ZSlcblxuICAgICAgICBjb25zdCBzZXZlbkRheXNBZ28gPSBuZXcgRGF0ZShEYXRlLm5vdygpIC0gNyAqIDI0ICogNjAgKiA2MCAqIDEwMDApLnRvSVNPU3RyaW5nKClcbiAgICAgICAgY29uc3QgeyBjb3VudDogcmVjZW50U2lnbnVwcyB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZmlsZXMnKS5zZWxlY3QoJyonLCB7IGNvdW50OiAnZXhhY3QnLCBoZWFkOiB0cnVlIH0pXG4gICAgICAgICAgICAuZXEoJ3JvbGUnLCAnc3R1ZGVudCcpXG4gICAgICAgICAgICAuZ3RlKCdjcmVhdGVkX2F0Jywgc2V2ZW5EYXlzQWdvKVxuXG4gICAgICAgIC8vIE1ldHJpY3MgQ2FsY3VsYXRpb25cbiAgICAgICAgY29uc3QgdG90YWxBY3RpdmVVc2VycyA9ICh0b3RhbFRyYWluZXJzIHx8IDApICsgKHRvdGFsU3R1ZGVudHMgfHwgMClcbiAgICAgICAgY29uc3QgYWN0aXZlVHJhaW5lcnNDb3VudCA9IHRvdGFsVHJhaW5lcnMgfHwgMFxuXG4gICAgICAgIC8vIFRpY2tldCBNw6lkaW8gKE7Ds3MpIC0+IFF1YW50byBnYW5oYW1vcyBwb3IgcGVyc29uYWwgY2FkYXN0cmFkb1xuICAgICAgICBjb25zdCBwbGF0Zm9ybVRpY2tldFBlclRyYWluZXIgPSBhY3RpdmVUcmFpbmVyc0NvdW50ID4gMCA/IChtb250aGx5R3Jvc3NSZXZlbnVlIC8gYWN0aXZlVHJhaW5lcnNDb3VudCkgOiAwXG5cbiAgICAgICAgLy8gVGlja2V0IE3DqWRpbyAoUGVyc29uYWwpIC0+IFF1YW50byBvIHBlcnNvbmFsIGdhbmhhIGVtIG3DqWRpYVxuICAgICAgICBjb25zdCB0cmFpbmVyQXZlcmFnZVRpY2tldCA9IGFjdGl2ZVRyYWluZXJzQ291bnQgPiAwID8gKG1vbnRobHlUcmFpbmVyVm9sdW1lIC8gYWN0aXZlVHJhaW5lcnNDb3VudCkgOiAwXG5cblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHJhaW5lcnM6IHRvdGFsVHJhaW5lcnMgfHwgMCxcbiAgICAgICAgICAgIHRyaWFsVHJhaW5lcnM6IHRyaWFsQ291bnQsXG4gICAgICAgICAgICBzdHVkZW50c0luVHJpYWwsXG4gICAgICAgICAgICBzdHVkZW50czogdG90YWxTdHVkZW50cyB8fCAwLFxuICAgICAgICAgICAgcmVsYXRpb25zaGlwczogdG90YWxSZWxhdGlvbnNoaXBzIHx8IDAsXG5cbiAgICAgICAgICAgIG1vbnRobHlUcmFpbmVyVm9sdW1lLFxuICAgICAgICAgICAgdG90YWxUcmFpbmVyVm9sdW1lLFxuXG4gICAgICAgICAgICBtb250aGx5UGxhdGZvcm1Qcm9maXQ6IG1vbnRobHlOZXRQcm9maXQsIC8vIE5vdyBOZXQgUHJvZml0XG4gICAgICAgICAgICB0b3RhbFBsYXRmb3JtUHJvZml0OiB0b3RhbE5ldFByb2ZpdCwgICAgIC8vIE5vdyBOZXQgUHJvZml0XG5cbiAgICAgICAgICAgIG1vbnRobHlHcm9zc1JldmVudWUsXG4gICAgICAgICAgICB0b3RhbEdyb3NzUmV2ZW51ZSxcblxuICAgICAgICAgICAgbW9udGhseU9wZXJhdGlvbmFsQ29zdHMsXG4gICAgICAgICAgICB0b3RhbE9wZXJhdGlvbmFsQ29zdHMsXG5cbiAgICAgICAgICAgIGFmZmlsaWF0ZXNDb3VudDogY291bnRBZmZpbGlhdGVzIHx8IDAsXG4gICAgICAgICAgICBhZmZpbGlhdGVEZWJ0OiBhZmZpbGlhdGVEZWJ0LFxuICAgICAgICAgICAgcHJvZHVjdENsaWNrczogcHJvZHVjdENsaWNrcyB8fCAwLFxuICAgICAgICAgICAgdG90YWxQcm9kdWN0czogdG90YWxQcm9kdWN0cyB8fCAwLFxuICAgICAgICAgICAgcmVjZW50U2lnbnVwczogcmVjZW50U2lnbnVwcyB8fCAwLFxuXG4gICAgICAgICAgICBhZmZpbGlhdGVUb3RhbEVhcm5pbmdzLFxuICAgICAgICAgICAgY29tbWlzc2lvbnNUaGlzTW9udGgsXG4gICAgICAgICAgICBwZW5kaW5nQ29tbWlzc2lvbnMsXG4gICAgICAgICAgICBwbGF0Zm9ybVRpY2tldFBlclRyYWluZXIsXG4gICAgICAgICAgICB0cmFpbmVyQXZlcmFnZVRpY2tldFxuICAgICAgICB9XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdBZG1pbiBvdmVydmlldyBlcnJvcjonLCBlKVxuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFVzZXJzKHJvbGU/OiBzdHJpbmcpIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlIH0gPSBhd2FpdCBjaGVja0FkbWluKClcbiAgICBsZXQgcXVlcnkgPSBzdXBhYmFzZS5mcm9tKCdwcm9maWxlcycpLnNlbGVjdCgnaWQsIGZ1bGxfbmFtZSwgZW1haWwsIHJvbGUsIHBsYW5fdGllciwgaXNfYWRtaW4sIGNyZWF0ZWRfYXQsIGF2YXRhcl91cmwsIHRyYWluZXJfY29kZSwgaXNfYmlsbGluZ19leGVtcHQnKVxuICAgIGlmIChyb2xlKSBxdWVyeSA9IHF1ZXJ5LmVxKCdyb2xlJywgcm9sZSlcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHF1ZXJ5Lm9yZGVyKCdjcmVhdGVkX2F0JywgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgcmV0dXJuIGRhdGEgfHwgW11cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFRyYWluZXJzKCkge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UgfSA9IGF3YWl0IGNoZWNrQWRtaW4oKVxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgLmZyb20oJ3Byb2ZpbGVzJylcbiAgICAgICAgLnNlbGVjdChgXG4gICAgICAgICAgICBpZCwgZnVsbF9uYW1lLCBlbWFpbCwgcGxhbl90aWVyLCBhdmVyYWdlX3JhdGluZywgdG90YWxfcmV2aWV3cywgaXNfZWxpdGUsIGNyZWF0ZWRfYXQsIGF2YXRhcl91cmwsIHRyYWluZXJfY29kZSwgc3BlY2lhbHR5LCByZWdpb24sIGlzX2JpbGxpbmdfZXhlbXB0LFxuICAgICAgICAgICAgc3R1ZGVudHM6dHJhaW5lcl9zdHVkZW50cyF0cmFpbmVyX2lkKG1vbnRobHlfZmVlLCBhY3RpdmUsIGNyZWF0ZWRfYXQpXG4gICAgICAgIGApXG4gICAgICAgIC5lcSgncm9sZScsICd0cmFpbmVyJylcbiAgICAgICAgLm9yZGVyKCdjcmVhdGVkX2F0JywgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG5cbiAgICByZXR1cm4gKGRhdGEgfHwgW10pLm1hcCgodDogYW55KSA9PiB7XG4gICAgICAgIGNvbnN0IHN0dWRlbnRzID0gdC5zdHVkZW50cyB8fCBbXVxuXG4gICAgICAgIC8vIE1vbnRobHkgUmVjdXJyaW5nIFJldmVudWVcbiAgICAgICAgY29uc3QgbW9udGhseVJldmVudWUgPSBzdHVkZW50cy5yZWR1Y2UoKHN1bTogbnVtYmVyLCBzOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBzLmFjdGl2ZSA/IHN1bSArIChOdW1iZXIocy5tb250aGx5X2ZlZSkgfHwgMCkgOiBzdW1cbiAgICAgICAgfSwgMClcblxuICAgICAgICAvLyBFc3RpbWF0ZWQgVG90YWwgUmV2ZW51ZSAoQWN0aXZlIFN0dWRlbnRzICogTW9udGhzIEFjdGl2ZSlcbiAgICAgICAgLy8gTm90ZTogRG9lcyBub3QgYWNjb3VudCBmb3IgcGFzdCBpbmFjdGl2ZSBzdHVkZW50cyBmdWxseSB3aXRob3V0IGhpc3RvcmljYWwgbG9ncy5cbiAgICAgICAgY29uc3QgdG90YWxSZXZlbnVlID0gc3R1ZGVudHMucmVkdWNlKChzdW06IG51bWJlciwgczogYW55KSA9PiB7XG4gICAgICAgICAgICBpZiAoIXMuYWN0aXZlKSByZXR1cm4gc3VtIC8vIElnbm9yZSBpbmFjdGl2ZSBmb3IgdG90YWwgYXMgd2UgZG9uJ3Qga25vdyBkdXJhdGlvblxuXG4gICAgICAgICAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHMuY3JlYXRlZF9hdClcbiAgICAgICAgICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcbiAgICAgICAgICAgIGNvbnN0IGRpZmZNb250aHMgPSAobm93LmdldEZ1bGxZZWFyKCkgLSBzdGFydC5nZXRGdWxsWWVhcigpKSAqIDEyICsgKG5vdy5nZXRNb250aCgpIC0gc3RhcnQuZ2V0TW9udGgoKSlcbiAgICAgICAgICAgIC8vIEluY2x1ZGUgcGFydGlhbCBtb250aCBhcyAxXG4gICAgICAgICAgICBjb25zdCBtb250aHMgPSBNYXRoLm1heCgxLCBkaWZmTW9udGhzICsgMSlcblxuICAgICAgICAgICAgcmV0dXJuIHN1bSArICgoTnVtYmVyKHMubW9udGhseV9mZWUpIHx8IDApICogbW9udGhzKVxuICAgICAgICB9LCAwKVxuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi50LFxuICAgICAgICAgICAgbW9udGhseV9yZXZlbnVlOiBtb250aGx5UmV2ZW51ZSxcbiAgICAgICAgICAgIHRvdGFsX3JldmVudWU6IHRvdGFsUmV2ZW51ZVxuICAgICAgICB9XG4gICAgfSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVVzZXJQbGFuVGllcih1c2VySWQ6IHN0cmluZywgcGxhblRpZXI6IHN0cmluZykge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UsIHVzZXJJZDogYWRtaW5JZCB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZmlsZXMnKS51cGRhdGUoe1xuICAgICAgICBwbGFuX3RpZXI6IHBsYW5UaWVyLFxuICAgICAgICBpc19iaWxsaW5nX2V4ZW1wdDogdHJ1ZSwgLy8gQXV0by1leGVtcHQgd2hlbiBhZG1pbiBhY3RpdmF0ZXMgbWFudWFsbHlcbiAgICAgICAgZWxpdGVfdW50aWw6IG51bGwgLy8gQ2xlYXIgdHJpYWwgc3RhdHVzIHdoZW4gbWFudWFsbHkgdXBkYXRpbmcgcGxhblxuICAgIH0pLmVxKCdpZCcsIHVzZXJJZClcbiAgICBpZiAoZXJyb3IpIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH1cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdhZG1pbl9sb2dzJykuaW5zZXJ0KHsgYWRtaW5faWQ6IGFkbWluSWQsIGFjdGlvbjogJ3VwZGF0ZV9wbGFuX3RpZXInLCB0YXJnZXRfaWQ6IHVzZXJJZCwgZGV0YWlsczogeyBwbGFuX3RpZXI6IHBsYW5UaWVyIH0gfSlcbiAgICByZXZhbGlkYXRlUGF0aCgnL2FkbWluJylcbiAgICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC90cmFpbmVyJywgJ2xheW91dCcpXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvdHJhaW5lci9wbGFucycpXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b2dnbGVFbGl0ZVN0YXR1cyh1c2VySWQ6IHN0cmluZywgaXNFbGl0ZTogYm9vbGVhbikge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UsIHVzZXJJZDogYWRtaW5JZCB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZmlsZXMnKS51cGRhdGUoeyBpc19lbGl0ZTogaXNFbGl0ZSB9KS5lcSgnaWQnLCB1c2VySWQpXG4gICAgaWYgKGVycm9yKSByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9XG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9hZG1pbicpXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvdHJhaW5lcicsICdsYXlvdXQnKVxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3RyYWluZXIvcGxhbnMnKVxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdG9nZ2xlQmlsbGluZ0V4ZW1wdGlvbih1c2VySWQ6IHN0cmluZywgaXNFeGVtcHQ6IGJvb2xlYW4pIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlLCB1c2VySWQ6IGFkbWluSWQgfSA9IGF3YWl0IGNoZWNrQWRtaW4oKVxuICAgIGNvbnN0IHsgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Byb2ZpbGVzJykudXBkYXRlKHsgaXNfYmlsbGluZ19leGVtcHQ6IGlzRXhlbXB0IH0pLmVxKCdpZCcsIHVzZXJJZClcbiAgICBpZiAoZXJyb3IpIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH1cblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2FkbWluX2xvZ3MnKS5pbnNlcnQoe1xuICAgICAgICBhZG1pbl9pZDogYWRtaW5JZCxcbiAgICAgICAgYWN0aW9uOiAndG9nZ2xlX2JpbGxpbmdfZXhlbXB0JyxcbiAgICAgICAgdGFyZ2V0X2lkOiB1c2VySWQsXG4gICAgICAgIGRldGFpbHM6IHsgaXNfYmlsbGluZ19leGVtcHQ6IGlzRXhlbXB0IH1cbiAgICB9KVxuXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9hZG1pbicpXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvdHJhaW5lcicsICdsYXlvdXQnKVxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3RyYWluZXIvcGxhbnMnKVxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ3JhbnRFbGl0ZVRyaWFsKHVzZXJJZDogc3RyaW5nKSB7XG4gICAgY29uc3QgeyBzdXBhYmFzZSwgdXNlcklkOiBhZG1pbklkIH0gPSBhd2FpdCBjaGVja0FkbWluKClcblxuICAgIGNvbnN0IGVsaXRlVW50aWwgPSBuZXcgRGF0ZSgpXG4gICAgZWxpdGVVbnRpbC5zZXREYXRlKGVsaXRlVW50aWwuZ2V0RGF0ZSgpICsgMTUpXG5cbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdwcm9maWxlcycpLnVwZGF0ZSh7XG4gICAgICAgIHBsYW5fdGllcjogJ2VsaXRlJyxcbiAgICAgICAgaXNfZWxpdGU6IHRydWUsXG4gICAgICAgIGVsaXRlX3VudGlsOiBlbGl0ZVVudGlsLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIHRyaWFsX2FjdGl2YXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgfSkuZXEoJ2lkJywgdXNlcklkKVxuXG4gICAgaWYgKGVycm9yKSByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9XG5cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdhZG1pbl9sb2dzJykuaW5zZXJ0KHtcbiAgICAgICAgYWRtaW5faWQ6IGFkbWluSWQsXG4gICAgICAgIGFjdGlvbjogJ2dyYW50X2VsaXRlX3RyaWFsJyxcbiAgICAgICAgdGFyZ2V0X2lkOiB1c2VySWQsXG4gICAgICAgIGRldGFpbHM6IHsgZWxpdGVfdW50aWw6IGVsaXRlVW50aWwudG9JU09TdHJpbmcoKSB9XG4gICAgfSlcblxuICAgIHJldmFsaWRhdGVQYXRoKCcvYWRtaW4nKVxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3RyYWluZXInLCAnbGF5b3V0JylcbiAgICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC90cmFpbmVyL3BsYW5zJylcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFsbFN0b3JlUHJvZHVjdHMoKSB7XG4gICAgY29uc3QgeyBzdXBhYmFzZSB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdzdG9yZV9wcm9kdWN0cycpLnNlbGVjdCgnKicpLm9yZGVyKCdjcmVhdGVkX2F0JywgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgcmV0dXJuIGRhdGEgfHwgW11cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHRvZ2dsZVByb2R1Y3RTdGF0dXMocHJvZHVjdElkOiBzdHJpbmcsIGlzQWN0aXZlOiBib29sZWFuKSB7XG4gICAgY29uc3QgeyBzdXBhYmFzZSwgdXNlcklkOiBhZG1pbklkIH0gPSBhd2FpdCBjaGVja0FkbWluKClcbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdzdG9yZV9wcm9kdWN0cycpLnVwZGF0ZSh7IGlzX2FjdGl2ZTogaXNBY3RpdmUgfSkuZXEoJ2lkJywgcHJvZHVjdElkKVxuICAgIGlmIChlcnJvcikgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfVxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2FkbWluX2xvZ3MnKS5pbnNlcnQoeyBhZG1pbl9pZDogYWRtaW5JZCwgYWN0aW9uOiAndG9nZ2xlX3Byb2R1Y3QnLCB0YXJnZXRfaWQ6IHByb2R1Y3RJZCwgZGV0YWlsczogeyBpc19hY3RpdmU6IGlzQWN0aXZlIH0gfSlcbiAgICByZXZhbGlkYXRlUGF0aCgnL2FkbWluJylcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkZFN0b3JlUHJvZHVjdChkYXRhOiB7XG4gICAgbmFtZTogc3RyaW5nXG4gICAgZGVzY3JpcHRpb246IHN0cmluZ1xuICAgIGltYWdlX3VybDogc3RyaW5nXG4gICAgb2ZmaWNpYWxfcHJpY2U6IG51bWJlclxuICAgIGxpbmtfdXJsOiBzdHJpbmdcbiAgICBjYXRlZ29yeTogc3RyaW5nXG4gICAgc3ViX2NhdGVnb3J5OiBzdHJpbmdcbiAgICByYXRpbmc/OiBudW1iZXJcbiAgICByZXZpZXdzX2NvdW50PzogbnVtYmVyXG59KSB7XG4gICAgY29uc3QgeyBzdXBhYmFzZSwgdXNlcklkOiBhZG1pbklkIH0gPSBhd2FpdCBjaGVja0FkbWluKClcblxuICAgIC8vIE1hcCBQVC1CUiBjYXRlZ29yaWVzIHRvIEVOIGtleXMgaWYgbmVlZGVkLCBvciB1bmlmeVxuICAgIGNvbnN0IGNhdGVnb3J5TWFwOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgICAgICAnU3VwbGVtZW50byc6ICdzdXBwbGVtZW50JyxcbiAgICAgICAgJ0FjZXNzw7NyaW8nOiAnYWNjZXNzb3J5JyxcbiAgICAgICAgJ1Zlc3R1w6FyaW8nOiAnY2xvdGhpbmcnLFxuICAgICAgICAnRXF1aXBhbWVudG8nOiAnZXF1aXBtZW50J1xuICAgIH1cbiAgICBjb25zdCBmaW5hbENhdGVnb3J5ID0gY2F0ZWdvcnlNYXBbZGF0YS5jYXRlZ29yeV0gfHwgZGF0YS5jYXRlZ29yeVxuXG4gICAgLy8gRW5zdXJlIGltYWdlIGlzIHBlcnNpc3RlZCBpbiBvdXIgc3RvcmFnZVxuICAgIGlmIChkYXRhLmltYWdlX3VybCAmJiBkYXRhLmltYWdlX3VybC5zdGFydHNXaXRoKCdodHRwJykgJiYgIWRhdGEuaW1hZ2VfdXJsLmluY2x1ZGVzKCdzdXBhYmFzZS5jbycpKSB7XG4gICAgICAgIGNvbnN0IHVwbG9hZGVkID0gYXdhaXQgdXBsb2FkSW1hZ2VGcm9tVXJsKGRhdGEuaW1hZ2VfdXJsKVxuICAgICAgICBpZiAodXBsb2FkZWQpIGRhdGEuaW1hZ2VfdXJsID0gdXBsb2FkZWRcbiAgICB9XG5cbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdzdG9yZV9wcm9kdWN0cycpLmluc2VydCh7XG4gICAgICAgIC4uLmRhdGEsXG4gICAgICAgIGNhdGVnb3J5OiBmaW5hbENhdGVnb3J5LFxuICAgICAgICBpc19hY3RpdmU6IHRydWVcbiAgICB9KVxuICAgIGlmIChlcnJvcikgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfVxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2FkbWluX2xvZ3MnKS5pbnNlcnQoeyBhZG1pbl9pZDogYWRtaW5JZCwgYWN0aW9uOiAnYWRkX3Byb2R1Y3QnLCBkZXRhaWxzOiB7IC4uLmRhdGEsIGNhdGVnb3J5OiBmaW5hbENhdGVnb3J5IH0gfSlcbiAgICByZXZhbGlkYXRlUGF0aCgnL2FkbWluJylcbiAgICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC9zdHVkZW50L2xvamEvZXhwbG9yYXInKVxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3RyYWluZXIvbG9qYS9leHBsb3JhcicpXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBZG1pbkxvZ3MoKSB7XG4gICAgY29uc3QgeyBzdXBhYmFzZSB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBkYXRhIH0gPSBhd2FpdCBzdXBhYmFzZVxuICAgICAgICAuZnJvbSgnYWRtaW5fbG9ncycpXG4gICAgICAgIC5zZWxlY3QoJyosIGFkbWluOnByb2ZpbGVzIWFkbWluX2lkKGZ1bGxfbmFtZSwgZW1haWwpJylcbiAgICAgICAgLm9yZGVyKCdjcmVhdGVkX2F0JywgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgICAgIC5saW1pdCg1MClcbiAgICByZXR1cm4gZGF0YSB8fCBbXVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9wUHJvZHVjdHNCeUNsaWNrcygpIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlIH0gPSBhd2FpdCBjaGVja0FkbWluKClcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKCdwcm9kdWN0X2NsaWNrcycpXG4gICAgICAgIC5zZWxlY3QoJ3Byb2R1Y3RfaWQsIHN0b3JlX3Byb2R1Y3RzKG5hbWUsIGltYWdlX3VybCwgY2F0ZWdvcnkpJylcbiAgICAgICAgLmxpbWl0KDEwMClcblxuICAgIGlmICghZGF0YSkgcmV0dXJuIFtdXG5cbiAgICAvLyBDb3VudCBjbGlja3MgcGVyIHByb2R1Y3RcbiAgICBjb25zdCBjb3VudHM6IFJlY29yZDxzdHJpbmcsIHsgbmFtZTogc3RyaW5nOyBpbWFnZV91cmw6IHN0cmluZzsgY2F0ZWdvcnk6IHN0cmluZzsgY2xpY2tzOiBudW1iZXIgfT4gPSB7fVxuICAgIGZvciAoY29uc3Qgcm93IG9mIGRhdGEpIHtcbiAgICAgICAgY29uc3QgcCA9IHJvdy5zdG9yZV9wcm9kdWN0cyBhcyBhbnlcbiAgICAgICAgaWYgKCFwKSBjb250aW51ZVxuICAgICAgICBjb25zdCBpZCA9IHJvdy5wcm9kdWN0X2lkXG4gICAgICAgIGlmICghY291bnRzW2lkXSkgY291bnRzW2lkXSA9IHsgbmFtZTogcC5uYW1lLCBpbWFnZV91cmw6IHAuaW1hZ2VfdXJsLCBjYXRlZ29yeTogcC5jYXRlZ29yeSwgY2xpY2tzOiAwIH1cbiAgICAgICAgY291bnRzW2lkXS5jbGlja3MrK1xuICAgIH1cbiAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMoY291bnRzKVxuICAgICAgICAubWFwKChbaWQsIHZdKSA9PiAoeyBpZCwgLi4udiB9KSlcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IGIuY2xpY2tzIC0gYS5jbGlja3MpXG4gICAgICAgIC5zbGljZSgwLCA1KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UmVjZW50U3R1ZGVudEFjdGl2aXR5KCkge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UgfSA9IGF3YWl0IGNoZWNrQWRtaW4oKVxuICAgIGNvbnN0IFt3b3Jrb3V0cywgY2FyZGlvc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbSgnd29ya291dF9sb2dzJylcbiAgICAgICAgICAgIC5zZWxlY3QoYFxuICAgICAgICAgICAgICAgIGlkLFxuICAgICAgICAgICAgICAgIGNyZWF0ZWRfYXQsXG4gICAgICAgICAgICAgICAgc3RhdHVzLFxuICAgICAgICAgICAgICAgIHN0dWRlbnQ6cHJvZmlsZXMhc3R1ZGVudF9pZChmdWxsX25hbWUsIGF2YXRhcl91cmwpLFxuICAgICAgICAgICAgICAgIHdvcmtvdXQ6d29ya291dHMobmFtZSlcbiAgICAgICAgICAgIGApXG4gICAgICAgICAgICAub3JkZXIoJ2NyZWF0ZWRfYXQnLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICAgICAgICAgIC5saW1pdCgxNSksXG4gICAgICAgIHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbSgnY2FyZGlvX2xvZ3MnKVxuICAgICAgICAgICAgLnNlbGVjdChgXG4gICAgICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICAgICAgY3JlYXRlZF9hdCxcbiAgICAgICAgICAgICAgICBzdGF0dXMsXG4gICAgICAgICAgICAgICAgc3R1ZGVudDpwcm9maWxlcyFzdHVkZW50X2lkKGZ1bGxfbmFtZSwgYXZhdGFyX3VybCksXG4gICAgICAgICAgICAgICAgY2FyZGlvOmFzc2lnbmVkX2NhcmRpb3MoY2FyZGlvOmNhcmRpb3MobmFtZSkpXG4gICAgICAgICAgICBgKVxuICAgICAgICAgICAgLm9yZGVyKCdjcmVhdGVkX2F0JywgeyBhc2NlbmRpbmc6IGZhbHNlIH0pXG4gICAgICAgICAgICAubGltaXQoMTUpXG4gICAgXSlcblxuICAgIGNvbnN0IHdvcmtvdXRBY3Rpdml0aWVzID0gKHdvcmtvdXRzLmRhdGEgfHwgW10pLm1hcCh3ID0+ICh7XG4gICAgICAgIC4uLncsXG4gICAgICAgIHR5cGU6ICd3b3Jrb3V0J1xuICAgIH0pKVxuXG4gICAgY29uc3QgY2FyZGlvQWN0aXZpdGllcyA9IChjYXJkaW9zLmRhdGEgfHwgW10pLm1hcChjID0+ICh7XG4gICAgICAgIC4uLmMsXG4gICAgICAgIHR5cGU6ICdjYXJkaW8nLFxuICAgICAgICB3b3Jrb3V0OiAoYyBhcyBhbnkpLmNhcmRpbz8uY2FyZGlvIC8vIG1hcHBpbmcgdG8gJ3dvcmtvdXQnIGtleSBzbyBmcm9udGVuZCBkb2Vzbid0IGJyZWFrXG4gICAgfSkpXG5cbiAgICBjb25zdCBjb21iaW5lZCA9IFsuLi53b3Jrb3V0QWN0aXZpdGllcywgLi4uY2FyZGlvQWN0aXZpdGllc11cbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IG5ldyBEYXRlKGIuY3JlYXRlZF9hdCkuZ2V0VGltZSgpIC0gbmV3IERhdGUoYS5jcmVhdGVkX2F0KS5nZXRUaW1lKCkpXG4gICAgICAgIC5zbGljZSgwLCAyMClcblxuICAgIHJldHVybiBjb21iaW5lZFxufVxuXG4vLyBEZWZhdWx0IHByaWNlcyAoZmFsbGJhY2sgaWYgbm90IGluIERCKVxuY29uc3QgREVGQVVMVF9QUklDRVM6IFJlY29yZDxzdHJpbmcsIHsgbW9udGhseTogbnVtYmVyOyBxdWFydGVybHlfZGlzY291bnQ6IG51bWJlcjsgYW5udWFsX2Rpc2NvdW50OiBudW1iZXIgfT4gPSB7XG4gICAgc3RhcnQ6IHsgbW9udGhseTogNDkuOTAsIHF1YXJ0ZXJseV9kaXNjb3VudDogMTUsIGFubnVhbF9kaXNjb3VudDogMjAgfSxcbiAgICBwcm86IHsgbW9udGhseTogMTQ5LjkwLCBxdWFydGVybHlfZGlzY291bnQ6IDE1LCBhbm51YWxfZGlzY291bnQ6IDIwIH0sXG4gICAgZWxpdGU6IHsgbW9udGhseTogMjk5LjkwLCBxdWFydGVybHlfZGlzY291bnQ6IDE1LCBhbm51YWxfZGlzY291bnQ6IDIwIH0sXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQbGFuUHJpY2luZygpIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlIH0gPSBhd2FpdCBjaGVja0FkbWluKClcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgIC5mcm9tKCdwbGFuX2ZlYXR1cmVzJylcbiAgICAgICAgLnNlbGVjdCgncGxhbl90aWVyLCBmZWF0dXJlX2tleSwgbGltaXRfdmFsdWUnKVxuICAgICAgICAuaW4oJ2ZlYXR1cmVfa2V5JywgW1xuICAgICAgICAgICAgJ21vbnRobHlfcHJpY2VfY2VudHMnLFxuICAgICAgICAgICAgJ3F1YXJ0ZXJseV9kaXNjb3VudF9wY3QnLFxuICAgICAgICAgICAgJ2FubnVhbF9kaXNjb3VudF9wY3QnLFxuICAgICAgICAgICAgJ3ByaWNlX3Blcl9zdHVkZW50X2NlbnRzJyxcbiAgICAgICAgICAgICdmcmVlX3N0dWRlbnRzX2xpbWl0JyxcbiAgICAgICAgICAgICdwcm9fZmVhdHVyZXNfdGhyZXNob2xkJ1xuICAgICAgICBdKVxuXG4gICAgY29uc3QgcmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB7XG4gICAgICAgIG1vbnRobHk6IG51bWJlcjtcbiAgICAgICAgcXVhcnRlcmx5X2Rpc2NvdW50OiBudW1iZXI7XG4gICAgICAgIGFubnVhbF9kaXNjb3VudDogbnVtYmVyO1xuICAgICAgICBwcmljZV9wZXJfc3R1ZGVudD86IG51bWJlcjtcbiAgICAgICAgZnJlZV9zdHVkZW50c19saW1pdD86IG51bWJlcjtcbiAgICAgICAgcHJvX2ZlYXR1cmVzX3RocmVzaG9sZD86IG51bWJlcjtcbiAgICB9PiA9IHtcbiAgICAgICAgb25fZGVtYW5kOiB7IG1vbnRobHk6IDAsIHF1YXJ0ZXJseV9kaXNjb3VudDogMCwgYW5udWFsX2Rpc2NvdW50OiAwLCBwcmljZV9wZXJfc3R1ZGVudDogMjAsIGZyZWVfc3R1ZGVudHNfbGltaXQ6IDUsIHByb19mZWF0dXJlc190aHJlc2hvbGQ6IDggfSxcbiAgICAgICAgc3RhcnQ6IHsgLi4uREVGQVVMVF9QUklDRVMuc3RhcnQgfSxcbiAgICAgICAgcHJvOiB7IC4uLkRFRkFVTFRfUFJJQ0VTLnBybyB9LFxuICAgICAgICBlbGl0ZTogeyAuLi5ERUZBVUxUX1BSSUNFUy5lbGl0ZSB9LFxuICAgIH1cblxuICAgIGZvciAoY29uc3Qgcm93IG9mIGRhdGEgfHwgW10pIHtcbiAgICAgICAgaWYgKCFyZXN1bHRbcm93LnBsYW5fdGllcl0pIGNvbnRpbnVlXG4gICAgICAgIGlmIChyb3cuZmVhdHVyZV9rZXkgPT09ICdtb250aGx5X3ByaWNlX2NlbnRzJykgcmVzdWx0W3Jvdy5wbGFuX3RpZXJdLm1vbnRobHkgPSAocm93LmxpbWl0X3ZhbHVlIHx8IDApIC8gMTAwXG4gICAgICAgIGlmIChyb3cuZmVhdHVyZV9rZXkgPT09ICdxdWFydGVybHlfZGlzY291bnRfcGN0JykgcmVzdWx0W3Jvdy5wbGFuX3RpZXJdLnF1YXJ0ZXJseV9kaXNjb3VudCA9IHJvdy5saW1pdF92YWx1ZSB8fCAwXG4gICAgICAgIGlmIChyb3cuZmVhdHVyZV9rZXkgPT09ICdhbm51YWxfZGlzY291bnRfcGN0JykgcmVzdWx0W3Jvdy5wbGFuX3RpZXJdLmFubnVhbF9kaXNjb3VudCA9IHJvdy5saW1pdF92YWx1ZSB8fCAwXG4gICAgICAgIGlmIChyb3cuZmVhdHVyZV9rZXkgPT09ICdwcmljZV9wZXJfc3R1ZGVudF9jZW50cycpIHJlc3VsdFtyb3cucGxhbl90aWVyXS5wcmljZV9wZXJfc3R1ZGVudCA9IChyb3cubGltaXRfdmFsdWUgfHwgMCkgLyAxMDBcbiAgICAgICAgaWYgKHJvdy5mZWF0dXJlX2tleSA9PT0gJ2ZyZWVfc3R1ZGVudHNfbGltaXQnKSByZXN1bHRbcm93LnBsYW5fdGllcl0uZnJlZV9zdHVkZW50c19saW1pdCA9IHJvdy5saW1pdF92YWx1ZSB8fCAwXG4gICAgICAgIGlmIChyb3cuZmVhdHVyZV9rZXkgPT09ICdwcm9fZmVhdHVyZXNfdGhyZXNob2xkJykgcmVzdWx0W3Jvdy5wbGFuX3RpZXJdLnByb19mZWF0dXJlc190aHJlc2hvbGQgPSByb3cubGltaXRfdmFsdWUgfHwgMFxuICAgIH1cblxuICAgIHJldHVybiByZXN1bHRcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVBsYW5QcmljaW5nKFxuICAgIHRpZXI6IHN0cmluZyxcbiAgICBtb250aGx5OiBudW1iZXIsXG4gICAgcXVhcnRlcmx5RGlzY291bnQ6IG51bWJlcixcbiAgICBhbm51YWxEaXNjb3VudDogbnVtYmVyLFxuICAgIGV4dHJhcz86IHtcbiAgICAgICAgcHJpY2VfcGVyX3N0dWRlbnQ/OiBudW1iZXI7XG4gICAgICAgIGZyZWVfc3R1ZGVudHNfbGltaXQ/OiBudW1iZXI7XG4gICAgICAgIHByb19mZWF0dXJlc190aHJlc2hvbGQ/OiBudW1iZXI7XG4gICAgfVxuKSB7XG4gICAgY29uc3QgeyBzdXBhYmFzZSwgdXNlcklkOiBhZG1pbklkIH0gPSBhd2FpdCBjaGVja0FkbWluKClcblxuICAgIGNvbnN0IHVwc2VydHMgPSBbXG4gICAgICAgIHsgcGxhbl90aWVyOiB0aWVyLCBmZWF0dXJlX2tleTogJ21vbnRobHlfcHJpY2VfY2VudHMnLCBsaW1pdF92YWx1ZTogTWF0aC5yb3VuZChtb250aGx5ICogMTAwKSB9LFxuICAgICAgICB7IHBsYW5fdGllcjogdGllciwgZmVhdHVyZV9rZXk6ICdxdWFydGVybHlfZGlzY291bnRfcGN0JywgbGltaXRfdmFsdWU6IHF1YXJ0ZXJseURpc2NvdW50IH0sXG4gICAgICAgIHsgcGxhbl90aWVyOiB0aWVyLCBmZWF0dXJlX2tleTogJ2FubnVhbF9kaXNjb3VudF9wY3QnLCBsaW1pdF92YWx1ZTogYW5udWFsRGlzY291bnQgfSxcbiAgICBdXG5cbiAgICBpZiAodGllciA9PT0gJ29uX2RlbWFuZCcgJiYgZXh0cmFzKSB7XG4gICAgICAgIGlmIChleHRyYXMucHJpY2VfcGVyX3N0dWRlbnQgIT09IHVuZGVmaW5lZCkgdXBzZXJ0cy5wdXNoKHsgcGxhbl90aWVyOiB0aWVyLCBmZWF0dXJlX2tleTogJ3ByaWNlX3Blcl9zdHVkZW50X2NlbnRzJywgbGltaXRfdmFsdWU6IE1hdGgucm91bmQoZXh0cmFzLnByaWNlX3Blcl9zdHVkZW50ICogMTAwKSB9KTtcbiAgICAgICAgaWYgKGV4dHJhcy5mcmVlX3N0dWRlbnRzX2xpbWl0ICE9PSB1bmRlZmluZWQpIHVwc2VydHMucHVzaCh7IHBsYW5fdGllcjogdGllciwgZmVhdHVyZV9rZXk6ICdmcmVlX3N0dWRlbnRzX2xpbWl0JywgbGltaXRfdmFsdWU6IGV4dHJhcy5mcmVlX3N0dWRlbnRzX2xpbWl0IH0pO1xuICAgICAgICBpZiAoZXh0cmFzLnByb19mZWF0dXJlc190aHJlc2hvbGQgIT09IHVuZGVmaW5lZCkgdXBzZXJ0cy5wdXNoKHsgcGxhbl90aWVyOiB0aWVyLCBmZWF0dXJlX2tleTogJ3Byb19mZWF0dXJlc190aHJlc2hvbGQnLCBsaW1pdF92YWx1ZTogZXh0cmFzLnByb19mZWF0dXJlc190aHJlc2hvbGQgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncGxhbl9mZWF0dXJlcycpLnVwc2VydCh1cHNlcnRzLCB7IG9uQ29uZmxpY3Q6ICdwbGFuX3RpZXIsZmVhdHVyZV9rZXknIH0pXG5cbiAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXBkYXRpbmcgcGxhbiBwcmljaW5nOicsIGVycm9yKVxuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfVxuICAgIH1cblxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2FkbWluX2xvZ3MnKS5pbnNlcnQoe1xuICAgICAgICBhZG1pbl9pZDogYWRtaW5JZCxcbiAgICAgICAgYWN0aW9uOiAndXBkYXRlX3BsYW5fcHJpY2luZycsXG4gICAgICAgIGRldGFpbHM6IHsgdGllciwgbW9udGhseSwgcXVhcnRlcmx5RGlzY291bnQsIGFubnVhbERpc2NvdW50LCBleHRyYXMgfVxuICAgIH0pXG5cbiAgICByZXZhbGlkYXRlUGF0aCgnL2FkbWluJylcbiAgICByZXZhbGlkYXRlUGF0aCgnL2Rhc2hib2FyZC90cmFpbmVyL3BsYW5zJylcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVVzZXIodXNlcklkOiBzdHJpbmcpIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlLCB1c2VySWQ6IGFkbWluSWQgfSA9IGF3YWl0IGNoZWNrQWRtaW4oKVxuICAgIGNvbnN0IGFkbWluID0gY3JlYXRlQWRtaW5DbGllbnQoKVxuXG4gICAgdHJ5IHtcbiAgICAgICAgLy8gUHJpbWVpcm8sIHZhbW9zIGRlbGV0YXIgbWFudWFsbWVudGUgYWxndW1hcyB0YWJlbGFzIHF1ZSBwb2RlbSBuw6NvIHRlciBDQVNDQURFXG4gICAgICAgIC8vIG91IHF1ZSBwcmVjaXNhbSBkZSBsaW1wZXphIGVzcGVjw61maWNhXG5cbiAgICAgICAgLy8gRGVsZXRhciBhcnF1aXZvcyBkbyBzdG9yYWdlIChhdmF0YXIsIHByb2dyZXNzIHBob3RvcywgZXRjKVxuICAgICAgICBjb25zdCB7IGRhdGE6IHByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbSgncHJvZmlsZXMnKVxuICAgICAgICAgICAgLnNlbGVjdCgnYXZhdGFyX3VybCcpXG4gICAgICAgICAgICAuZXEoJ2lkJywgdXNlcklkKVxuICAgICAgICAgICAgLnNpbmdsZSgpXG5cbiAgICAgICAgaWYgKHByb2ZpbGU/LmF2YXRhcl91cmwpIHtcbiAgICAgICAgICAgIGNvbnN0IGF2YXRhclBhdGggPSBwcm9maWxlLmF2YXRhcl91cmwuc3BsaXQoJy8nKS5zbGljZSgtMikuam9pbignLycpXG4gICAgICAgICAgICBpZiAoYXZhdGFyUGF0aCkge1xuICAgICAgICAgICAgICAgIGF3YWl0IHN1cGFiYXNlLnN0b3JhZ2VcbiAgICAgICAgICAgICAgICAgICAgLmZyb20oJ2F2YXRhcnMnKVxuICAgICAgICAgICAgICAgICAgICAucmVtb3ZlKFthdmF0YXJQYXRoXSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIERlbGV0YXIgcHJvZ3Jlc3MgcGhvdG9zIGRvIHN0b3JhZ2VcbiAgICAgICAgY29uc3QgeyBkYXRhOiBwcm9ncmVzc1Bob3RvcyB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKCdwcm9ncmVzc19waG90b3MnKVxuICAgICAgICAgICAgLnNlbGVjdCgnZnJvbnRfdXJsLCBiYWNrX3VybCwgc2lkZV9sZWZ0X3VybCwgc2lkZV9yaWdodF91cmwnKVxuICAgICAgICAgICAgLmVxKCdzdHVkZW50X2lkJywgdXNlcklkKVxuXG4gICAgICAgIGlmIChwcm9ncmVzc1Bob3Rvcykge1xuICAgICAgICAgICAgY29uc3QgcGhvdG9QYXRoczogc3RyaW5nW10gPSBbXVxuICAgICAgICAgICAgcHJvZ3Jlc3NQaG90b3MuZm9yRWFjaChwaG90byA9PiB7XG4gICAgICAgICAgICAgICAgWydmcm9udF91cmwnLCAnYmFja191cmwnLCAnc2lkZV9sZWZ0X3VybCcsICdzaWRlX3JpZ2h0X3VybCddLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdXJsID0gKHBob3RvIGFzIGFueSlba2V5XVxuICAgICAgICAgICAgICAgICAgICBpZiAodXJsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXRoID0gdXJsLnNwbGl0KCcvcHJvZ3Jlc3MtcGhvdG9zLycpWzFdXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAocGF0aCkgcGhvdG9QYXRocy5wdXNoKHBhdGgpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIGlmIChwaG90b1BhdGhzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAgICAgICAgICAgICAgIC5mcm9tKCdwcm9ncmVzcy1waG90b3MnKVxuICAgICAgICAgICAgICAgICAgICAucmVtb3ZlKHBob3RvUGF0aHMpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBEZWxldGFyIFBERnMgZG8gc3RvcmFnZVxuICAgICAgICBjb25zdCB7IGRhdGE6IHBkZlVwbG9hZHMgfSA9IGF3YWl0IHN1cGFiYXNlXG4gICAgICAgICAgICAuZnJvbSgncGRmX3VwbG9hZHMnKVxuICAgICAgICAgICAgLnNlbGVjdCgnZmlsZV91cmwnKVxuICAgICAgICAgICAgLmVxKCd1cGxvYWRlcl9pZCcsIHVzZXJJZClcblxuICAgICAgICBpZiAocGRmVXBsb2Fkcykge1xuICAgICAgICAgICAgY29uc3QgcGRmUGF0aHM6IHN0cmluZ1tdID0gW11cbiAgICAgICAgICAgIHBkZlVwbG9hZHMuZm9yRWFjaChwZGYgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChwZGYuZmlsZV91cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGF0aCA9IHBkZi5maWxlX3VybC5zcGxpdCgnLycpLnNsaWNlKC0yKS5qb2luKCcvJylcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhdGgpIHBkZlBhdGhzLnB1c2gocGF0aClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgaWYgKHBkZlBhdGhzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAgICAgICAgICAgICAgIC5mcm9tKCdwZGYtdXBsb2FkcycpXG4gICAgICAgICAgICAgICAgICAgIC5yZW1vdmUocGRmUGF0aHMpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBMb2cgZGEgYcOnw6NvIGFudGVzIGRlIGRlbGV0YXJcbiAgICAgICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnYWRtaW5fbG9ncycpLmluc2VydCh7XG4gICAgICAgICAgICBhZG1pbl9pZDogYWRtaW5JZCxcbiAgICAgICAgICAgIGFjdGlvbjogJ2RlbGV0ZV91c2VyJyxcbiAgICAgICAgICAgIHRhcmdldF9pZDogdXNlcklkLFxuICAgICAgICAgICAgZGV0YWlsczogeyBkZWxldGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfVxuICAgICAgICB9KVxuXG4gICAgICAgIC8vIERlbGV0YXIgbyBwcm9maWxlIChpc3NvIHZhaSBjYXNjYXRlYXIgcGFyYSBtdWl0YXMgdGFiZWxhcyBkZXZpZG8gYW8gT04gREVMRVRFIENBU0NBREUpXG4gICAgICAgIGNvbnN0IHsgZXJyb3I6IHByb2ZpbGVFcnJvciB9ID0gYXdhaXQgc3VwYWJhc2VcbiAgICAgICAgICAgIC5mcm9tKCdwcm9maWxlcycpXG4gICAgICAgICAgICAuZGVsZXRlKClcbiAgICAgICAgICAgIC5lcSgnaWQnLCB1c2VySWQpXG5cbiAgICAgICAgaWYgKHByb2ZpbGVFcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignRXJybyBhbyBkZWxldGFyIHByb2ZpbGU6JywgcHJvZmlsZUVycm9yKVxuICAgICAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGBFcnJvIGFvIGRlbGV0YXIgZGFkb3M6ICR7cHJvZmlsZUVycm9yLm1lc3NhZ2V9YCB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBEZWxldGFyIG8gdXN1w6FyaW8gZG8gYXV0aCAocmVxdWVyIGFkbWluIGNsaWVudClcbiAgICAgICAgaWYgKCFhZG1pbikge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignREVMRVRFX1VTRVJfRVJST1I6IFNVUEFCQVNFX1NFUlZJQ0VfUk9MRV9LRVkgaXMgbWlzc2luZyBvciBhZG1pbiBjbGllbnQgZmFpbGVkIHRvIGluaXRpYWxpemUuJylcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgICAgICB3YXJuaW5nOiAnRGFkb3MgY29sZXRhZG9zIGUgcmVtb3ZpZG9zIGRvIGJhbmNvLCBtYXMgYSBjb250YSBkZSBMT0dJTiBhaW5kYSBleGlzdGUuIE1vdGl2bzogQ2hhdmUgZGUgQWRtaW4gbsOjbyBlbmNvbnRyYWRhIG5vIHNlcnZpZG9yLidcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHsgZXJyb3I6IGF1dGhFcnJvciB9ID0gYXdhaXQgYWRtaW4uYXV0aC5hZG1pbi5kZWxldGVVc2VyKHVzZXJJZClcblxuICAgICAgICBpZiAoYXV0aEVycm9yKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdERUxFVEVfVVNFUl9BVVRIX0VSUk9SOicsIGF1dGhFcnJvcilcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgICAgICB3YXJuaW5nOiBgRGFkb3MgZG8gcGVyZmlsIGFwYWdhZG9zLCBtYXMgaG91dmUgZXJybyBubyBsb2dpbjogJHthdXRoRXJyb3IubWVzc2FnZX1gXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICByZXZhbGlkYXRlUGF0aCgnL2FkbWluJylcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0RFTEVURV9VU0VSX0NSSVRJQ0FMX0VSUk9SOicsIGUpXG4gICAgICAgIHJldHVybiB7IGVycm9yOiBgRXJybyBpbmVzcGVyYWRvOiAke2UubWVzc2FnZSB8fCAnQ29uc3VsdGUgb3MgbG9ncyBkbyBzZXJ2aWRvcid9YCB9XG4gICAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU3RvcmVQcm9kdWN0KGlkOiBzdHJpbmcsIGRhdGE6IGFueSkge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UsIHVzZXJJZDogYWRtaW5JZCB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG5cbiAgICAvLyBNYXAgUFQtQlIgY2F0ZWdvcmllcyB0byBFTiBrZXlzXG4gICAgY29uc3QgY2F0ZWdvcnlNYXA6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG4gICAgICAgICdTdXBsZW1lbnRvJzogJ3N1cHBsZW1lbnQnLFxuICAgICAgICAnQWNlc3PDs3Jpbyc6ICdhY2Nlc3NvcnknLFxuICAgICAgICAnVmVzdHXDoXJpbyc6ICdjbG90aGluZycsXG4gICAgICAgICdFcXVpcGFtZW50byc6ICdlcXVpcG1lbnQnXG4gICAgfVxuICAgIGlmIChkYXRhLmNhdGVnb3J5ICYmIGNhdGVnb3J5TWFwW2RhdGEuY2F0ZWdvcnldKSB7XG4gICAgICAgIGRhdGEuY2F0ZWdvcnkgPSBjYXRlZ29yeU1hcFtkYXRhLmNhdGVnb3J5XVxuICAgIH1cblxuICAgIC8vIEVuc3VyZSBpbWFnZSBpcyBwZXJzaXN0ZWQgaW4gb3VyIHN0b3JhZ2UgKGlmIGl0J3MgYSBuZXcgZXh0ZXJuYWwgVVJMKVxuICAgIGlmIChkYXRhLmltYWdlX3VybCAmJiBkYXRhLmltYWdlX3VybC5zdGFydHNXaXRoKCdodHRwJykgJiYgIWRhdGEuaW1hZ2VfdXJsLmluY2x1ZGVzKCdzdXBhYmFzZS5jbycpKSB7XG4gICAgICAgIGNvbnN0IHVwbG9hZGVkID0gYXdhaXQgdXBsb2FkSW1hZ2VGcm9tVXJsKGRhdGEuaW1hZ2VfdXJsKVxuICAgICAgICBpZiAodXBsb2FkZWQpIGRhdGEuaW1hZ2VfdXJsID0gdXBsb2FkZWRcbiAgICB9XG5cbiAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdzdG9yZV9wcm9kdWN0cycpLnVwZGF0ZShkYXRhKS5lcSgnaWQnLCBpZClcbiAgICBpZiAoZXJyb3IpIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH1cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdhZG1pbl9sb2dzJykuaW5zZXJ0KHsgYWRtaW5faWQ6IGFkbWluSWQsIGFjdGlvbjogJ3VwZGF0ZV9wcm9kdWN0JywgdGFyZ2V0X2lkOiBpZCwgZGV0YWlsczogZGF0YSB9KVxuICAgIHJldmFsaWRhdGVQYXRoKCcvYWRtaW4nKVxuICAgIHJldmFsaWRhdGVQYXRoKCcvZGFzaGJvYXJkL3N0dWRlbnQvbG9qYS9leHBsb3JhcicpXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9kYXNoYm9hcmQvdHJhaW5lci9sb2phL2V4cGxvcmFyJylcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGltcGVyc29uYXRlVXNlcih0YXJnZXRVc2VySWQ6IHN0cmluZykge1xuICAgIC8vIDEuIENoZWNrIGlmIGN1cnJlbnQgdXNlciBpcyBhZG1pbiBPUiBpZiB3ZSBhcmUgYWxyZWFkeSBpbXBlcnNvbmF0aW5nICh0byBhbGxvdyBnb2luZyBiYWNrKVxuICAgIGNvbnN0IHN1cGFiYXNlID0gYXdhaXQgY3JlYXRlQ2xpZW50KClcbiAgICBjb25zdCBjb29raWVTdG9yZSA9IGF3YWl0IGNvb2tpZXMoKVxuICAgIGNvbnN0IGlzQ3VycmVudGx5SW1wZXJzb25hdGluZyA9IChhd2FpdCBjb29raWVTdG9yZSkuZ2V0KCdydF9pbXBlcnNvbmF0aW5nJyk/LnZhbHVlID09PSAndHJ1ZSdcblxuICAgIGxldCBhZG1pbklkID0gJydcblxuICAgIGlmICghaXNDdXJyZW50bHlJbXBlcnNvbmF0aW5nKSB7XG4gICAgICAgIGNvbnN0IHsgZGF0YTogeyB1c2VyOiBhZG1pblVzZXIgfSB9ID0gYXdhaXQgc3VwYWJhc2UuYXV0aC5nZXRVc2VyKClcbiAgICAgICAgaWYgKCFhZG1pblVzZXIpIHJldHVybiB7IGVycm9yOiAnTsOjbyBhdXRvcml6YWRvJyB9XG4gICAgICAgIGNvbnN0IHsgZGF0YTogcHJvZmlsZSB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgncHJvZmlsZXMnKS5zZWxlY3QoJ2lzX2FkbWluJykuZXEoJ2lkJywgYWRtaW5Vc2VyLmlkKS5zaW5nbGUoKVxuICAgICAgICBpZiAoIXByb2ZpbGU/LmlzX2FkbWluKSByZXR1cm4geyBlcnJvcjogJ0FwZW5hcyBhZG1pbnMgcG9kZW0gaW1wZXJzb25hciB1c3XDoXJpb3MnIH1cbiAgICAgICAgYWRtaW5JZCA9IGFkbWluVXNlci5pZFxuICAgIH0gZWxzZSB7XG4gICAgICAgIGFkbWluSWQgPSAoYXdhaXQgY29va2llU3RvcmUpLmdldCgncnRfYWRtaW5faWQnKT8udmFsdWUgfHwgJydcbiAgICB9XG5cbiAgICAvLyAyLiBHZXQgdGFyZ2V0IHVzZXIgZW1haWxcbiAgICBjb25zdCB7IGRhdGE6IHRhcmdldFByb2ZpbGUgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ3Byb2ZpbGVzJykuc2VsZWN0KCdlbWFpbCwgcm9sZScpLmVxKCdpZCcsIHRhcmdldFVzZXJJZCkuc2luZ2xlKClcbiAgICBpZiAoIXRhcmdldFByb2ZpbGU/LmVtYWlsKSByZXR1cm4geyBlcnJvcjogJ1VzdcOhcmlvIG7Do28gZW5jb250cmFkbyBvdSBzZW0gZS1tYWlsJyB9XG5cbiAgICAvLyAzLiBHZW5lcmF0ZSBsb2dpbiBsaW5rIHVzaW5nIEFkbWluIENsaWVudFxuICAgIGNvbnN0IGFkbWluID0gY3JlYXRlQWRtaW5DbGllbnQoKVxuICAgIGlmICghYWRtaW4pIHJldHVybiB7IGVycm9yOiAnRXJybyBkZSBjb25maWd1cmHDp8OjbyBkbyBzZXJ2aWRvciAoQWRtaW4gU0RLKScgfVxuXG4gICAgY29uc3QgeyBkYXRhLCBlcnJvciB9ID0gYXdhaXQgYWRtaW4uYXV0aC5hZG1pbi5nZW5lcmF0ZUxpbmsoe1xuICAgICAgICB0eXBlOiAnbWFnaWNsaW5rJyxcbiAgICAgICAgZW1haWw6IHRhcmdldFByb2ZpbGUuZW1haWwsXG4gICAgICAgIG9wdGlvbnM6IHsgcmVkaXJlY3RUbzogJy8nIH1cbiAgICB9KVxuXG4gICAgaWYgKGVycm9yIHx8ICFkYXRhLnByb3BlcnRpZXM/LmVtYWlsX290cCkge1xuICAgICAgICByZXR1cm4geyBlcnJvcjogYEVycm8gYW8gZ2VyYXIgbGluayBkZSBhY2Vzc286ICR7ZXJyb3I/Lm1lc3NhZ2UgfHwgJ1Rva2VuIG7Do28gZ2VyYWRvJ31gIH1cbiAgICB9XG5cbiAgICAvLyA0LiBWZXJpZnkgT1RQICh0aGlzIHNpZ25zIGluIHRoZSB1c2VyIGFuZCBzZXRzIGNvb2tpZXMpXG4gICAgY29uc3QgeyBlcnJvcjogdmVyaWZ5RXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGgudmVyaWZ5T3RwKHtcbiAgICAgICAgZW1haWw6IHRhcmdldFByb2ZpbGUuZW1haWwsXG4gICAgICAgIHRva2VuOiBkYXRhLnByb3BlcnRpZXMuZW1haWxfb3RwLFxuICAgICAgICB0eXBlOiAnbWFnaWNsaW5rJ1xuICAgIH0pXG5cbiAgICBpZiAodmVyaWZ5RXJyb3IpIHJldHVybiB7IGVycm9yOiBgRXJybyBhbyBhcGxpY2FyIHNlc3PDo286ICR7dmVyaWZ5RXJyb3IubWVzc2FnZX1gIH1cblxuICAgIC8vIDUuIFNldCBoZWxwZXIgY29va2llcyBmb3Igb3VyIEltcGVyc29uYXRpb25CYXJcbiAgICBjb25zdCBleHBpcmVzID0gbmV3IERhdGUoRGF0ZS5ub3coKSArIDYwICogNjAgKiAxMDAwKSAvLyAxIGhvdXJcblxuICAgIGlmICghaXNDdXJyZW50bHlJbXBlcnNvbmF0aW5nKSB7XG4gICAgICAgIChhd2FpdCBjb29raWVTdG9yZSkuc2V0KCdydF9pbXBlcnNvbmF0aW5nJywgJ3RydWUnLCB7IGV4cGlyZXMgfSk7XG4gICAgICAgIChhd2FpdCBjb29raWVTdG9yZSkuc2V0KCdydF9hZG1pbl9pZCcsIGFkbWluSWQsIHsgZXhwaXJlcyB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJZiB3ZSB3ZXJlIGdvaW5nIGJhY2sgdG8gYWRtaW4sIGNsZWFyIHRoZSBmbGFnc1xuICAgICAgICBjb25zdCB7IGRhdGE6IG9yaWdpbmFsQWRtaW5Qcm9maWxlIH0gPSBhd2FpdCBzdXBhYmFzZS5mcm9tKCdwcm9maWxlcycpLnNlbGVjdCgnaXNfYWRtaW4nKS5lcSgnaWQnLCB0YXJnZXRVc2VySWQpLnNpbmdsZSgpXG4gICAgICAgIGlmIChvcmlnaW5hbEFkbWluUHJvZmlsZT8uaXNfYWRtaW4pIHtcbiAgICAgICAgICAgIChhd2FpdCBjb29raWVTdG9yZSkuZGVsZXRlKCdydF9pbXBlcnNvbmF0aW5nJyk7XG4gICAgICAgICAgICAoYXdhaXQgY29va2llU3RvcmUpLmRlbGV0ZSgncnRfYWRtaW5faWQnKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIDYuIFJlZGlyZWN0IHRvIHByb3BlciBkYXNoYm9hcmQgYmFzZWQgb24gcm9sZVxuICAgIGlmICh0YXJnZXRQcm9maWxlLnJvbGUgPT09ICd0cmFpbmVyJykgcmVkaXJlY3QoJy9kYXNoYm9hcmQvdHJhaW5lcicpXG4gICAgaWYgKHRhcmdldFByb2ZpbGUucm9sZSA9PT0gJ3N0dWRlbnQnKSByZWRpcmVjdCgnL2Rhc2hib2FyZC9zdHVkZW50JylcblxuICAgIHJlZGlyZWN0KCcvZGFzaGJvYXJkJylcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVN0b3JlUHJvZHVjdChwcm9kdWN0SWQ6IHN0cmluZykge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UsIHVzZXJJZDogYWRtaW5JZCB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgnc3RvcmVfcHJvZHVjdHMnKS5kZWxldGUoKS5lcSgnaWQnLCBwcm9kdWN0SWQpXG4gICAgaWYgKGVycm9yKSByZXR1cm4geyBlcnJvcjogZXJyb3IubWVzc2FnZSB9XG4gICAgYXdhaXQgc3VwYWJhc2UuZnJvbSgnYWRtaW5fbG9ncycpLmluc2VydCh7IGFkbWluX2lkOiBhZG1pbklkLCBhY3Rpb246ICdkZWxldGVfcHJvZHVjdCcsIHRhcmdldF9pZDogcHJvZHVjdElkIH0pXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9hZG1pbicpXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHVwbG9hZEltYWdlRnJvbVVybCh1cmw6IHN0cmluZywgcHJlZml4OiBzdHJpbmcgPSAncHJvZHVjdCcpIHtcbiAgICBpZiAoIXVybCB8fCAhdXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSB8fCB1cmwuaW5jbHVkZXMoJ3N1cGFiYXNlLmNvJykpIHJldHVybiB1cmxcblxuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgJ1VzZXItQWdlbnQnOiAnTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMC4wLjAuMCBTYWZhcmkvNTM3LjM2J1xuICAgICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBmZXRjaCBpbWFnZTogJHtyZXNwb25zZS5zdGF0dXNUZXh0fWApXG4gICAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgcmVzcG9uc2UuYXJyYXlCdWZmZXIoKVxuICAgICAgICBjb25zdCBidWZmZXIgPSBCdWZmZXIuZnJvbShhcnJheUJ1ZmZlcilcblxuICAgICAgICBjb25zdCBzdXBhYmFzZSA9IGNyZWF0ZUFkbWluQ2xpZW50KClcbiAgICAgICAgaWYgKCFzdXBhYmFzZSkgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gY3JlYXRlIGFkbWluIGNsaWVudCcpXG5cbiAgICAgICAgY29uc3QgY29udGVudFR5cGUgPSByZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykgfHwgJ2ltYWdlL2pwZWcnXG4gICAgICAgIGNvbnN0IGV4dCA9IGNvbnRlbnRUeXBlLnNwbGl0KCcvJylbMV0/LnNwbGl0KCc7JylbMF0gfHwgJ2pwZydcbiAgICAgICAgY29uc3QgZmlsZU5hbWUgPSBgJHtwcmVmaXh9LSR7RGF0ZS5ub3coKX0tJHtNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoNyl9LiR7ZXh0fWBcblxuICAgICAgICBjb25zdCB7IGVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAgICAgICAuZnJvbSgnc3RvcmUtcHJvZHVjdHMnKVxuICAgICAgICAgICAgLnVwbG9hZChmaWxlTmFtZSwgYnVmZmVyLCB7XG4gICAgICAgICAgICAgICAgY29udGVudFR5cGUsXG4gICAgICAgICAgICAgICAgdXBzZXJ0OiB0cnVlXG4gICAgICAgICAgICB9KVxuXG4gICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgLy8gVHJ5IHRvIGNyZWF0ZSBidWNrZXQgaWYgaXQgZG9lc24ndCBleGlzdFxuICAgICAgICAgICAgaWYgKGVycm9yLm1lc3NhZ2UuaW5jbHVkZXMoJ25vdCBmb3VuZCcpIHx8IChlcnJvciBhcyBhbnkpLnN0YXR1cyA9PT0gNDA0KSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgc3VwYWJhc2Uuc3RvcmFnZS5jcmVhdGVCdWNrZXQoJ3N0b3JlLXByb2R1Y3RzJywgeyBwdWJsaWM6IHRydWUgfSlcbiAgICAgICAgICAgICAgICBjb25zdCB7IGVycm9yOiByZXRyeUVycm9yIH0gPSBhd2FpdCBzdXBhYmFzZS5zdG9yYWdlXG4gICAgICAgICAgICAgICAgICAgIC5mcm9tKCdzdG9yZS1wcm9kdWN0cycpXG4gICAgICAgICAgICAgICAgICAgIC51cGxvYWQoZmlsZU5hbWUsIGJ1ZmZlciwgeyBjb250ZW50VHlwZSwgdXBzZXJ0OiB0cnVlIH0pXG4gICAgICAgICAgICAgICAgaWYgKHJldHJ5RXJyb3IpIHRocm93IHJldHJ5RXJyb3JcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgZXJyb3JcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IHsgZGF0YTogeyBwdWJsaWNVcmwgfSB9ID0gc3VwYWJhc2Uuc3RvcmFnZVxuICAgICAgICAgICAgLmZyb20oJ3N0b3JlLXByb2R1Y3RzJylcbiAgICAgICAgICAgIC5nZXRQdWJsaWNVcmwoZmlsZU5hbWUpXG5cbiAgICAgICAgcmV0dXJuIHB1YmxpY1VybFxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHVwbG9hZGluZyBpbWFnZTonLCBlcnJvcilcbiAgICAgICAgcmV0dXJuIHVybCAvLyBGYWxsYmFja1xuICAgIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUHJvZHVjdEZyb21VcmwodXJsOiBzdHJpbmcpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zb2xlLmxvZyhgW0ZldGNoXSBTdGFydGluZyBpbXBvcnQgZm9yOiAke3VybH1gKVxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAnVXNlci1BZ2VudCc6ICdNb3ppbGxhLzUuMCAoV2luZG93cyBOVCAxMC4wOyBXaW42NDsgeDY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMTI4LjAuMC4wIFNhZmFyaS81MzcuMzYnLFxuICAgICAgICAgICAgICAgICdBY2NlcHQnOiAndGV4dC9odG1sLGFwcGxpY2F0aW9uL3hodG1sK3htbCxhcHBsaWNhdGlvbi94bWw7cT0wLjksaW1hZ2UvYXZpZixpbWFnZS93ZWJwLGltYWdlL2FwbmcsKi8qO3E9MC44JyxcbiAgICAgICAgICAgICAgICAnQWNjZXB0LUxhbmd1YWdlJzogJ3B0LUJSLHB0O3E9MC45LGVuLVVTO3E9MC44LGVuO3E9MC43JyxcbiAgICAgICAgICAgICAgICAnQ2FjaGUtQ29udHJvbCc6ICduby1jYWNoZScsXG4gICAgICAgICAgICAgICAgJ1ByYWdtYSc6ICduby1jYWNoZSdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZWRpcmVjdDogJ2ZvbGxvdydcbiAgICAgICAgfSlcbiAgICAgICAgaWYgKCFyZXMub2spIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGxvYWQgVVJMOiAke3Jlcy5zdGF0dXN9YClcbiAgICAgICAgY29uc3QgaHRtbCA9IGF3YWl0IHJlcy50ZXh0KClcbiAgICAgICAgY29uc3QgZmluYWxVcmwgPSByZXMudXJsXG4gICAgICAgIGNvbnNvbGUubG9nKGBbRmV0Y2hdIEZpbmFsIFVSTCBhZnRlciByZWRpcmVjdHM6ICR7ZmluYWxVcmx9YClcblxuICAgICAgICBjb25zdCBnZXRNZXRhID0gKHByb3A6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVnZXggPSBuZXcgUmVnRXhwKGA8bWV0YVtePl0qKD86cHJvcGVydHl8bmFtZXxpdGVtcHJvcCk9W1wiJ10ke3Byb3B9W1wiJ11bXj5dKmNvbnRlbnQ9W1wiJ10oW15cIiddKilbXCInXWAsICdpJylcbiAgICAgICAgICAgICAgICB8fCBuZXcgUmVnRXhwKGA8bWV0YVtePl0qY29udGVudD1bXCInXShbXlwiJ10qKVtcIiddW14+XSooPzpwcm9wZXJ0eXxuYW1lfGl0ZW1wcm9wKT1bXCInXSR7cHJvcH1bXCInXWAsICdpJylcbiAgICAgICAgICAgIGNvbnN0IG1hdGNoID0gaHRtbC5tYXRjaChyZWdleClcbiAgICAgICAgICAgIHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbFxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IHRpdGxlID0gZ2V0TWV0YSgnb2c6dGl0bGUnKSB8fCBnZXRNZXRhKCd0d2l0dGVyOnRpdGxlJykgfHwgKGh0bWwubWF0Y2goLzx0aXRsZT4oW148XSopPFxcL3RpdGxlPi9pKT8uWzFdKSB8fCAnJ1xuICAgICAgICBsZXQgZGVzY3JpcHRpb24gPSBnZXRNZXRhKCdvZzpkZXNjcmlwdGlvbicpIHx8IGdldE1ldGEoJ2Rlc2NyaXB0aW9uJykgfHwgJydcbiAgICAgICAgbGV0IGltYWdlID0gZ2V0TWV0YSgnb2c6aW1hZ2UnKSB8fCBnZXRNZXRhKCd0d2l0dGVyOmltYWdlJykgfHwgJydcbiAgICAgICAgbGV0IHByaWNlU3RyID0gZ2V0TWV0YSgncHJvZHVjdDpwcmljZTphbW91bnQnKSB8fCBnZXRNZXRhKCdwcmljZScpIHx8IGdldE1ldGEoJ3R3aXR0ZXI6ZGF0YTEnKVxuXG4gICAgICAgIC8vIE1lcmNhZG8gTGl2cmUgc3BlY2lmaWMgZGVzY3JpcHRpb24gc2VsZWN0b3JzICh0byBhdm9pZCBnZW5lcmljIHN0b3JlIGRlc2NyaXB0aW9ucylcbiAgICAgICAgY29uc3QgbWxEZXNjTWF0Y2ggPSBodG1sLm1hdGNoKC88cCBjbGFzcz1cInVpLXBkcC1kZXNjcmlwdGlvbl9fY29udGVudFwiPihbXFxzXFxTXSo/KTxcXC9wPi9pKVxuICAgICAgICBpZiAobWxEZXNjTWF0Y2ggJiYgbWxEZXNjTWF0Y2hbMV0ubGVuZ3RoID4gNTApIHtcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uID0gbWxEZXNjTWF0Y2hbMV0udHJpbSgpXG4gICAgICAgIH1cblxuICAgICAgICAvLyBUcnkgdG8gZmluZCBwcmljZSBpbiBzdGFuZGFyZCBjbGFzc2VzL3RhZ3MgaWYgbWV0YSBmYWlsc1xuICAgICAgICBpZiAoIXByaWNlU3RyKSB7XG4gICAgICAgICAgICAvLyBNTCBwcmljZSBzZWxlY3RvcnMgKGZyYWN0aW9uICsgY2VudHMpXG4gICAgICAgICAgICBjb25zdCBmcmFjdGlvbiA9IGh0bWwubWF0Y2goL2NsYXNzPVwiYW5kZXMtbW9uZXktYW1vdW50X19mcmFjdGlvblwiW14+XSo+KFtcXGQuLF0rKTxcXC9zcGFuPi9pKT8uWzFdXG4gICAgICAgICAgICBjb25zdCBjZW50cyA9IGh0bWwubWF0Y2goL2NsYXNzPVwiYW5kZXMtbW9uZXktYW1vdW50X19jZW50c1wiW14+XSo+KFxcZCspPFxcL3NwYW4+L2kpPy5bMV0gfHwgJzAwJ1xuXG4gICAgICAgICAgICBpZiAoZnJhY3Rpb24pIHtcbiAgICAgICAgICAgICAgICBwcmljZVN0ciA9IGAke2ZyYWN0aW9ufS4ke2NlbnRzfWBcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gQWx0ZXJuYXRpdmUgTUwgb3IgZ2VuZXJpYyBwcmljZVxuICAgICAgICAgICAgICAgIGNvbnN0IGdlblByaWNlID0gaHRtbC5tYXRjaCgvaXRlbXByb3A9XCJwcmljZVwiIGNvbnRlbnQ9XCIoW1xcZC5dKylcIi9pKVxuICAgICAgICAgICAgICAgICAgICB8fCBodG1sLm1hdGNoKC9cInByaWNlXCI6XFxzKihbXFxkLl0rKS9pKVxuICAgICAgICAgICAgICAgICAgICB8fCBodG1sLm1hdGNoKC9SXFwkXFxzKihbXFxkLixdKykvaSlcbiAgICAgICAgICAgICAgICBpZiAoZ2VuUHJpY2UpIHByaWNlU3RyID0gZ2VuUHJpY2VbMV1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJhdGluZyBleHRyYWN0aW9uXG4gICAgICAgIGxldCByYXRpbmcgPSAwXG4gICAgICAgIGxldCByZXZpZXdzID0gMFxuXG4gICAgICAgIC8vIFRyeSB0byBmaW5kIHJhdGluZyBpbiBBUklBIGxhYmVscyBvciB2aXN1YWxseSBoaWRkZW4gc3BhbnMgKENvbW1vbiBpbiBNTClcbiAgICAgICAgY29uc3QgdmlzdWFsbHlIaWRkZW5NYXRjaCA9IGh0bWwubWF0Y2goL2NsYXNzPVwiYW5kZXMtdmlzdWFsbHktaGlkZGVuXCI+QXZhbGlhw6fDo29cXHMqKFtcXGQuLF0rKVxccypkZVxccyo1XFwuXFxzKihbXFxkLl0rKVxccypvcGluacO1ZXMvaSlcbiAgICAgICAgICAgIHx8IGh0bWwubWF0Y2goL2NsYXNzPVwiYW5kZXMtdmlzdWFsbHktaGlkZGVuXCI+QXZhbGlhZG8gY29tIChbXFxkLixdKylcXHMqZXN0cmVsYXMvaSlcblxuICAgICAgICBpZiAodmlzdWFsbHlIaWRkZW5NYXRjaCkge1xuICAgICAgICAgICAgcmF0aW5nID0gcGFyc2VGbG9hdCh2aXN1YWxseUhpZGRlbk1hdGNoWzFdLnJlcGxhY2UoJywnLCAnLicpKVxuICAgICAgICAgICAgaWYgKHZpc3VhbGx5SGlkZGVuTWF0Y2hbMl0pIHtcbiAgICAgICAgICAgICAgICByZXZpZXdzID0gcGFyc2VJbnQodmlzdWFsbHlIaWRkZW5NYXRjaFsyXS5yZXBsYWNlKC9cXC4vZywgJycpKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFyYXRpbmcpIHtcbiAgICAgICAgICAgIGNvbnN0IGFyaWFSYXRpbmcgPSBodG1sLm1hdGNoKC9hcmlhLWxhYmVsPVwiKFtcXGQuLF0rKVxccyplc3RyZWxhcy9pKSB8fCBodG1sLm1hdGNoKC9hcmlhLWxhYmVsPVwiQXZhbGlhZG8gY29tIChbXFxkLixdKylcXHMqZXN0cmVsYXMvaSlcbiAgICAgICAgICAgIGlmIChhcmlhUmF0aW5nKSByYXRpbmcgPSBwYXJzZUZsb2F0KGFyaWFSYXRpbmdbMV0ucmVwbGFjZSgnLCcsICcuJykpXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXJldmlld3MpIHtcbiAgICAgICAgICAgIGNvbnN0IGFyaWFSZXZpZXdzID0gaHRtbC5tYXRjaCgvYXJpYS1sYWJlbD1cIihbXFxkLl0rKVxccypvcGluacO1ZXMvaSkgfHwgaHRtbC5tYXRjaCgvXFwoKFtcXGQuXSspXFwpXFxzKm9waW5pw7Vlcy9pKVxuICAgICAgICAgICAgaWYgKGFyaWFSZXZpZXdzKSByZXZpZXdzID0gcGFyc2VJbnQoYXJpYVJldmlld3NbMV0ucmVwbGFjZSgvXFwuL2csICcnKSlcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGpzb25MZE1hdGNoID0gaHRtbC5tYXRjaCgvPHNjcmlwdCB0eXBlPVwiYXBwbGljYXRpb25cXC9sZFxcK2pzb25cIj4oW1xcc1xcU10qPyk8XFwvc2NyaXB0Pi9pKVxuICAgICAgICBpZiAoanNvbkxkTWF0Y2gpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5uZXIgPSBqc29uTGRNYXRjaFsxXS50cmltKClcbiAgICAgICAgICAgICAgICBjb25zdCBqc29uID0gSlNPTi5wYXJzZShpbm5lcilcbiAgICAgICAgICAgICAgICBjb25zdCBwcm9kdWN0ID0gQXJyYXkuaXNBcnJheShqc29uKSA/IGpzb24uZmluZChpID0+IGlbJ0B0eXBlJ10gPT09ICdQcm9kdWN0JykgOiAoanNvblsnQHR5cGUnXSA9PT0gJ1Byb2R1Y3QnID8ganNvbiA6IG51bGwpXG4gICAgICAgICAgICAgICAgaWYgKHByb2R1Y3QpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHByb2R1Y3QuYWdncmVnYXRlUmF0aW5nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJhdGluZykgcmF0aW5nID0gcGFyc2VGbG9hdChwcm9kdWN0LmFnZ3JlZ2F0ZVJhdGluZy5yYXRpbmdWYWx1ZSB8fCAwKVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFyZXZpZXdzKSByZXZpZXdzID0gcGFyc2VJbnQocHJvZHVjdC5hZ2dyZWdhdGVSYXRpbmcucmV2aWV3Q291bnQgfHwgMClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoIXByaWNlU3RyICYmIHByb2R1Y3Qub2ZmZXJzPy5wcmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcHJpY2VTdHIgPSBwcm9kdWN0Lm9mZmVycy5wcmljZS50b1N0cmluZygpXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFpbWFnZSAmJiBwcm9kdWN0LmltYWdlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpbWFnZSA9IEFycmF5LmlzQXJyYXkocHJvZHVjdC5pbWFnZSkgPyBwcm9kdWN0LmltYWdlWzBdIDogcHJvZHVjdC5pbWFnZVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZSkgeyB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBIYW5kbGUgcHJpY2UgaW4gdGl0bGUgKGNvbW1vbiBpbiBNZXJjYWRvIExpdnJlOiBcIlByb2R1Y3QgTmFtZSAtIFIkIDUwLDAwXCIpXG4gICAgICAgIGNvbnN0IHByaWNlUmVnZXggPSAvUlxcJFxccyooW1xcZC4sXSspL2lcbiAgICAgICAgY29uc3QgbWF0Y2ggPSB0aXRsZS5tYXRjaChwcmljZVJlZ2V4KVxuXG4gICAgICAgIGlmIChtYXRjaCkge1xuICAgICAgICAgICAgaWYgKCFwcmljZVN0cikgcHJpY2VTdHIgPSBtYXRjaFsxXVxuICAgICAgICAgICAgdGl0bGUgPSB0aXRsZS5yZXBsYWNlKG1hdGNoWzBdLCAnJykudHJpbSgpXG4gICAgICAgICAgICBpZiAodGl0bGUuZW5kc1dpdGgoJy0nKSkgdGl0bGUgPSB0aXRsZS5zdWJzdHJpbmcoMCwgdGl0bGUubGVuZ3RoIC0gMSkudHJpbSgpXG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcHJpY2UgPSAwXG4gICAgICAgIGlmIChwcmljZVN0cikge1xuICAgICAgICAgICAgbGV0IGNsZWFuID0gcHJpY2VTdHIudG9TdHJpbmcoKS5yZXBsYWNlKC9bXlxcZC4sXS9nLCAnJylcbiAgICAgICAgICAgIGlmIChjbGVhbi5pbmNsdWRlcygnLCcpKSB7XG4gICAgICAgICAgICAgICAgaWYgKGNsZWFuLmluY2x1ZGVzKCcuJykpIGNsZWFuID0gY2xlYW4ucmVwbGFjZSgvXFwuL2csICcnKS5yZXBsYWNlKCcsJywgJy4nKVxuICAgICAgICAgICAgICAgIGVsc2UgY2xlYW4gPSBjbGVhbi5yZXBsYWNlKCcsJywgJy4nKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcHJpY2UgPSBwYXJzZUZsb2F0KGNsZWFuKVxuICAgICAgICB9XG5cbiAgICAgICAgbGV0IGZpbmFsRGF0YTogYW55ID0ge1xuICAgICAgICAgICAgdGl0bGU6IHRpdGxlIHx8ICcnLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uIHx8ICcnLFxuICAgICAgICAgICAgaW1hZ2U6IGltYWdlIHx8ICcnLFxuICAgICAgICAgICAgcHJpY2U6IHByaWNlIHx8IDAsXG4gICAgICAgICAgICByYXRpbmc6IHJhdGluZyB8fCAwLFxuICAgICAgICAgICAgcmV2aWV3c19jb3VudDogcmV2aWV3cyB8fCAwXG4gICAgICAgIH1cblxuICAgICAgICAvLyBBSSBJbnRlZ3JhdGlvblxuICAgICAgICBjb25zdCBvcGVucm91dGVyS2V5ID0gcHJvY2Vzcy5lbnYuT1BFTlJPVVRFUl9BUElfS0VZXG4gICAgICAgIGlmIChvcGVucm91dGVyS2V5KSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgY3JlYXRlT3BlblJvdXRlckNsaWVudCwgY2FsbEFJLCBERUZBVUxUX0FJX01PREVMIH0gPSBhd2FpdCBpbXBvcnQoJ0AvbGliL2FpLWNsaWVudCcpXG4gICAgICAgICAgICAgICAgY29uc3QgY2xpZW50ID0gY3JlYXRlT3BlblJvdXRlckNsaWVudChvcGVucm91dGVyS2V5KVxuXG4gICAgICAgICAgICAgICAgLy8gSGVscCBBSSBieSBpZGVudGlmeWluZyB0aGUgc2l0ZVxuICAgICAgICAgICAgICAgIGNvbnN0IGlzTUwgPSBmaW5hbFVybC5pbmNsdWRlcygnbWVyY2Fkb2xpdnJlLmNvbScpIHx8IGZpbmFsVXJsLmluY2x1ZGVzKCdtZWxpLmxhJylcblxuICAgICAgICAgICAgICAgIGNvbnN0IGJvZHlUZXh0ID0gaHRtbC5tYXRjaCgvPGJvZHlbXj5dKj4oW1xcc1xcU10qKTxcXC9ib2R5Pi9pKT8uWzFdIHx8IGh0bWxcbiAgICAgICAgICAgICAgICBjb25zdCBjbGVhbkJvZHkgPSBib2R5VGV4dFxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvPHNjcmlwdFtePl0qPltcXHNcXFNdKj88XFwvc2NyaXB0Pi9naSwgJycpXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC88c3R5bGVbXj5dKj5bXFxzXFxTXSo/PFxcL3N0eWxlPi9naSwgJycpXG4gICAgICAgICAgICAgICAgICAgIC5yZXBsYWNlKC88bmF2W14+XSo+W1xcc1xcU10qPzxcXC9uYXY+L2dpLCAnJylcbiAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoLzxmb290ZXJbXj5dKj5bXFxzXFxTXSo/PFxcL2Zvb3Rlcj4vZ2ksICcnKVxuICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvPHN2Z1tePl0qPltcXHNcXFNdKj88XFwvc3ZnPi9naSwgJycpXG4gICAgICAgICAgICAgICAgICAgIC5zdWJzdHJpbmcoMCwgMTgwMDApXG5cbiAgICAgICAgICAgICAgICBjb25zdCBwcm9tcHQgPSBgXG5FeHRyYWN0IE1BSU4gcHJvZHVjdCBpbmZvcm1hdGlvbiBmcm9tIHRoaXMgSFRNTCBmcm9tICR7aXNNTCA/ICdNZXJjYWRvIExpdnJlJyA6ICdTdG9yZSd9LlxuU2l0ZTogJHtmaW5hbFVybH1cblxuREFUQSBFWFRSQUNUSU9OIFJVTEVTOlxuMS4gXCJ0aXRsZVwiOiBDTEVBTiBwcm9kdWN0IG5hbWUgT05MWS4gTm8gc2xvZ2Fucywgc2VsbGVyIG5hbWVzLCBvciBcIkZyZWUgU2hpcHBpbmdcIi5cbjIuIFwiZGVzY3JpcHRpb25cIjogXG4gICAtIElHTk9SRSBzZWxsZXIgbWV0YWRhdGEgbGlrZSBcIlZpc2l0ZSBhIHDDoWdpbmEgZSBlbmNvbnRyZSB0b2RvcyBvcyBwcm9kdXRvcyBkZS4uLlwiLlxuICAgLSBFeHRyYWN0IHRoZSBBQ1RVQUwgcHJvZHVjdCBiZW5lZml0cyBhbmQgdGVjaG5pY2FsIGZlYXR1cmVzLlxuICAgLSBTdW1tYXJpemUgaW50byAyIHBhcmFncmFwaHMgaWYgdG9vIGxvbmcuXG4zLiBcInByaWNlXCI6IEZpbmQgdGhlIG51bWVyaWMgcHJpY2UgKExvb2sgZm9yIFIkLCBkZWNpbWFscywgb3IgbWV0YSB0YWdzKS5cbjQuIFwicmF0aW5nXCI6IExvb2sgZm9yIFwiZXN0cmVsYXNcIiwgXCJub3RhXCIgb3IgYWdncmVnYXRlUmF0aW5nICgwIHRvIDUpLlxuNS4gXCJyZXZpZXdzX2NvdW50XCI6IE51bWJlciBvZiByZXZpZXdzL29waW5pb25zL2F2YWxpYWNvZXMuXG42LiBcImltYWdlXCI6IFVSTCBvZiB0aGUgcHJpbWFyeSwgaGlnaC1yZXNvbHV0aW9uIHByb2R1Y3QgaW1hZ2UuXG43LiBcImNhdGVnb3J5XCI6IFwic3VwcGxlbWVudFwiIHwgXCJhY2Nlc3NvcnlcIiB8IFwiY2xvdGhpbmdcIiB8IFwiZXF1aXBtZW50XCIuXG44LiBcInN1Yl9jYXRlZ29yeVwiOiBJZiBzdXBwbGVtZW50LCBcIldoZXlcIiB8IFwiUHLDqS10cmVpbm9cIiB8IFwiQ3JlYXRpbmFcIiB8IFwiVml0YW1pbmFzXCIgfCBcIk91dHJvc1wiLlxuXG5IVE1MIENvbnRlbnQ6XG4ke2NsZWFuQm9keX1cbmBcbiAgICAgICAgICAgICAgICBjb25zdCBhaVJlc3BvbnNlID0gYXdhaXQgY2FsbEFJKGNsaWVudCwgcHJvbXB0LCBERUZBVUxUX0FJX01PREVMKVxuICAgICAgICAgICAgICAgIGlmIChhaVJlc3BvbnNlICYmICFhaVJlc3BvbnNlLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGZpbmFsRGF0YSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBhaVJlc3BvbnNlLnRpdGxlIHx8IGZpbmFsRGF0YS50aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBhaVJlc3BvbnNlLmRlc2NyaXB0aW9uIHx8IGZpbmFsRGF0YS5kZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlOiBhaVJlc3BvbnNlLmltYWdlIHx8IGZpbmFsRGF0YS5pbWFnZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByaWNlOiBhaVJlc3BvbnNlLnByaWNlIHx8IGZpbmFsRGF0YS5wcmljZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJhdGluZzogYWlSZXNwb25zZS5yYXRpbmcgfHwgZmluYWxEYXRhLnJhdGluZyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldmlld3NfY291bnQ6IGFpUmVzcG9uc2UucmV2aWV3c19jb3VudCB8fCBmaW5hbERhdGEucmV2aWV3c19jb3VudCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiBhaVJlc3BvbnNlLmNhdGVnb3J5IHx8ICdzdXBwbGVtZW50JyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1Yl9jYXRlZ29yeTogYWlSZXNwb25zZS5zdWJfY2F0ZWdvcnkgfHwgJydcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGFpRXJyKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignQUkgZXh0cmFjdGlvbiBmYWlsZWQ6JywgYWlFcnIpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBBVVRPIFVQTE9BRCBJTUFHRSBUTyBTVVBBQkFTRVxuICAgICAgICBpZiAoZmluYWxEYXRhLmltYWdlKSB7XG4gICAgICAgICAgICBjb25zdCB1cGxvYWRlZFVybCA9IGF3YWl0IHVwbG9hZEltYWdlRnJvbVVybChmaW5hbERhdGEuaW1hZ2UpXG4gICAgICAgICAgICBpZiAodXBsb2FkZWRVcmwpIGZpbmFsRGF0YS5pbWFnZSA9IHVwbG9hZGVkVXJsXG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gZmluYWxEYXRhXG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdGZXRjaCBlcnJvcjonLCBlKVxuICAgICAgICByZXR1cm4geyBlcnJvcjogJ0ZhbGhhIGFvIGJ1c2NhciBkYWRvcy4gVmVyaWZpcXVlIG8gbGluayBlIHRlbnRlIG5vdmFtZW50ZS4nIH1cbiAgICB9XG59XG5cbi8vIE9wZXJhdGlvbmFsIENvc3RzIEFjdGlvbnNcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZGRPcGVyYXRpb25hbENvc3QoZGF0YTogeyBkZXNjcmlwdGlvbjogc3RyaW5nOyBhbW91bnQ6IG51bWJlcjsgdHlwZTogJ2ZpeGVkJyB8ICd2YXJpYWJsZScgfSkge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UsIHVzZXJJZDogYWRtaW5JZCB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgnb3BlcmF0aW9uYWxfY29zdHMnKS5pbnNlcnQoeyAuLi5kYXRhLCBhZG1pbl9pZDogYWRtaW5JZCB9KVxuICAgIGlmIChlcnJvcikgcmV0dXJuIHsgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfVxuICAgIGF3YWl0IHN1cGFiYXNlLmZyb20oJ2FkbWluX2xvZ3MnKS5pbnNlcnQoeyBhZG1pbl9pZDogYWRtaW5JZCwgYWN0aW9uOiAnYWRkX2Nvc3QnLCBkZXRhaWxzOiBkYXRhIH0pXG4gICAgcmV2YWxpZGF0ZVBhdGgoJy9hZG1pbicpXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVPcGVyYXRpb25hbENvc3QoaWQ6IHN0cmluZykge1xuICAgIGNvbnN0IHsgc3VwYWJhc2UsIHVzZXJJZDogYWRtaW5JZCB9ID0gYXdhaXQgY2hlY2tBZG1pbigpXG4gICAgY29uc3QgeyBlcnJvciB9ID0gYXdhaXQgc3VwYWJhc2UuZnJvbSgnb3BlcmF0aW9uYWxfY29zdHMnKS5kZWxldGUoKS5lcSgnaWQnLCBpZClcbiAgICBpZiAoZXJyb3IpIHJldHVybiB7IGVycm9yOiBlcnJvci5tZXNzYWdlIH1cbiAgICBhd2FpdCBzdXBhYmFzZS5mcm9tKCdhZG1pbl9sb2dzJykuaW5zZXJ0KHsgYWRtaW5faWQ6IGFkbWluSWQsIGFjdGlvbjogJ2RlbGV0ZV9jb3N0JywgdGFyZ2V0X2lkOiBpZCB9KVxuICAgIHJldmFsaWRhdGVQYXRoKCcvYWRtaW4nKVxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0T3BlcmF0aW9uYWxDb3N0cygpIHtcbiAgICBjb25zdCB7IHN1cGFiYXNlIH0gPSBhd2FpdCBjaGVja0FkbWluKClcbiAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IHN1cGFiYXNlLmZyb20oJ29wZXJhdGlvbmFsX2Nvc3RzJykuc2VsZWN0KCcqJykub3JkZXIoJ2NyZWF0ZWRfYXQnLCB7IGFzY2VuZGluZzogZmFsc2UgfSlcbiAgICByZXR1cm4gZGF0YSB8fCBbXVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI4VUFnc0JzQiw4TEFBQSJ9
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/class-variance-authority/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Slot$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@radix-ui/react-slot/dist/index.mjs [app-client] (ecmascript) <export * as Slot>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/utils.ts [app-client] (ecmascript)");
;
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none", {
    variants: {
        variant: {
            default: "bg-primary text-primary-foreground hover:bg-primary/90",
            destructive: "bg-destructive text-white hover:bg-destructive/90",
            outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground",
            secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
            ghost: "hover:bg-accent hover:text-accent-foreground",
            link: "text-primary underline-offset-4 hover:underline"
        },
        size: {
            default: "h-9 px-4 py-2 has-[>svg]:px-3",
            xs: "h-6 gap-1 rounded-md px-2 text-xs has-[>svg]:px-1.5 [&_svg:not([class*='size-'])]:size-3",
            sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
            lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
            icon: "size-9",
            "icon-xs": "size-6 rounded-md [&_svg:not([class*='size-'])]:size-3",
            "icon-sm": "size-8",
            "icon-lg": "size-10"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
function Button(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "59a94b3f4c720f675c7e80841723e9670b0de65ebb897b6b714db67b73a4b688") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "59a94b3f4c720f675c7e80841723e9670b0de65ebb897b6b714db67b73a4b688";
    }
    let className;
    let props;
    let t1;
    let t2;
    let t3;
    if ($[1] !== t0) {
        ({ className, variant: t1, size: t2, asChild: t3, ...props } = t0);
        $[1] = t0;
        $[2] = className;
        $[3] = props;
        $[4] = t1;
        $[5] = t2;
        $[6] = t3;
    } else {
        className = $[2];
        props = $[3];
        t1 = $[4];
        t2 = $[5];
        t3 = $[6];
    }
    const variant = t1 === undefined ? "default" : t1;
    const size = t2 === undefined ? "default" : t2;
    const asChild = t3 === undefined ? false : t3;
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Slot$3e$__["Slot"].Root : "button";
    let t4;
    if ($[7] !== className || $[8] !== size || $[9] !== variant) {
        t4 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        }));
        $[7] = className;
        $[8] = size;
        $[9] = variant;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== Comp || $[12] !== props || $[13] !== size || $[14] !== t4 || $[15] !== variant) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
            "data-slot": "button",
            "data-variant": variant,
            "data-size": size,
            className: t4,
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/button.tsx",
            lineNumber: 86,
            columnNumber: 10
        }, this);
        $[11] = Comp;
        $[12] = props;
        $[13] = size;
        $[14] = t4;
        $[15] = variant;
        $[16] = t5;
    } else {
        t5 = $[16];
    }
    return t5;
}
_c = Button;
;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ImpersonationBar",
    ()=>ImpersonationBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$actions$2f$data$3a$217b6a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/actions/data:217b6a [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/shield-alert.js [app-client] (ecmascript) <export default as ShieldAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftRight$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/arrow-left-right.js [app-client] (ecmascript) <export default as ArrowLeftRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/hooks/use-toast.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function ImpersonationBar() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "e23f014d9d2317281ccaab00c545938962638505a798f0c90d9c2ad1983f8000") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "e23f014d9d2317281ccaab00c545938962638505a798f0c90d9c2ad1983f8000";
    }
    const [isImpersonating, setIsImpersonating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [adminId, setAdminId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { toast } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    let t0;
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = ({
            "ImpersonationBar[useEffect()]": ()=>{
                const checkStatus = {
                    "ImpersonationBar[useEffect() > checkStatus]": ()=>{
                        const cookies = document.cookie.split("; ");
                        const imp = cookies.find(_ImpersonationBarUseEffectCheckStatusCookiesFind)?.split("=")[1];
                        const aid = cookies.find(_ImpersonationBarUseEffectCheckStatusCookiesFind2)?.split("=")[1];
                        setIsImpersonating(imp === "true");
                        setAdminId(aid || null);
                    }
                }["ImpersonationBar[useEffect() > checkStatus]"];
                checkStatus();
                const interval = setInterval(checkStatus, 2000);
                return ()=>clearInterval(interval);
            }
        })["ImpersonationBar[useEffect()]"];
        t1 = [];
        $[1] = t0;
        $[2] = t1;
    } else {
        t0 = $[1];
        t1 = $[2];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t0, t1);
    if (!isImpersonating || !adminId) {
        return null;
    }
    let t2;
    if ($[3] !== adminId || $[4] !== toast) {
        t2 = ({
            "ImpersonationBar[handleReturn]": async ()=>{
                setLoading(true);
                toast({
                    title: "Retornando ao Admin...",
                    description: "Estamos restaurando sua sess\xE3o original."
                });
                const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$actions$2f$data$3a$217b6a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["impersonateUser"])(adminId);
                if (res?.error) {
                    toast({
                        variant: "destructive",
                        title: "Erro ao retornar",
                        description: res.error
                    });
                    setLoading(false);
                }
            }
        })["ImpersonationBar[handleReturn]"];
        $[3] = adminId;
        $[4] = toast;
        $[5] = t2;
    } else {
        t2 = $[5];
    }
    const handleReturn = t2;
    let t3;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-1 px-2 bg-zinc-950 rounded flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$alert$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldAlert$3e$__["ShieldAlert"], {
                            className: "w-3.5 h-3.5 text-amber-500"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
                            lineNumber: 82,
                            columnNumber: 121
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-[10px] font-black uppercase tracking-widest text-white",
                            children: "Modo Inspeção Ativo"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
                            lineNumber: 82,
                            columnNumber: 175
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
                    lineNumber: 82,
                    columnNumber: 51
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-[11px] font-bold hidden sm:block",
                    children: "Você está visualizando a plataforma como outro usuário. Todas as ações afetarão a conta dele."
                }, void 0, false, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
                    lineNumber: 82,
                    columnNumber: 285
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== loading) {
        t4 = loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-3 h-3 border-2 border-amber-500 border-t-white rounded-full animate-spin"
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
            lineNumber: 89,
            columnNumber: 20
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$left$2d$right$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftRight$3e$__["ArrowLeftRight"], {
            className: "w-3.5 h-3.5 text-amber-500"
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
            lineNumber: 89,
            columnNumber: 117
        }, this);
        $[7] = loading;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== handleReturn || $[10] !== loading || $[11] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed top-0 left-0 right-0 z-[9999] bg-amber-500 text-zinc-950 px-4 py-2 border-b border-amber-600 shadow-2xl flex items-center justify-between animate-in slide-in-from-top duration-500",
            children: [
                t3,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: handleReturn,
                        disabled: loading,
                        size: "sm",
                        className: "h-8 bg-zinc-950 hover:bg-zinc-900 text-white border-none rounded-xl text-[10px] font-black uppercase tracking-widest gap-2 shadow-lg",
                        children: [
                            t4,
                            "Voltar ao Admin"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
                        lineNumber: 97,
                        columnNumber: 258
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
                    lineNumber: 97,
                    columnNumber: 217
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/admin/impersonation-bar.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[9] = handleReturn;
        $[10] = loading;
        $[11] = t4;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    return t5;
}
_s(ImpersonationBar, "PRFvGJ6oDqZzptBnP2tHuahC5sg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$hooks$2f$use$2d$toast$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c = ImpersonationBar;
function _ImpersonationBarUseEffectCheckStatusCookiesFind2(c_0) {
    return c_0.startsWith("rt_admin_id=");
}
function _ImpersonationBarUseEffectCheckStatusCookiesFind(c) {
    return c.startsWith("rt_impersonating=");
}
var _c;
__turbopack_context__.k.register(_c, "ImpersonationBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/providers/query-provider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "QueryProvider",
    ()=>QueryProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@tanstack/query-core/build/modern/queryClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function QueryProvider(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "2184adb135c4af73d029f74bbfa47e5edc8d9ed8bcd1c3c4276a48b0d9cbe347") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2184adb135c4af73d029f74bbfa47e5edc8d9ed8bcd1c3c4276a48b0d9cbe347";
    }
    const { children } = t0;
    const [queryClient] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(_QueryProviderUseState);
    let t1;
    if ($[1] !== children || $[2] !== queryClient) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClientProvider"], {
            client: queryClient,
            children: children
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/providers/query-provider.tsx",
            lineNumber: 20,
            columnNumber: 10
        }, this);
        $[1] = children;
        $[2] = queryClient;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_s(QueryProvider, "0C9cZBrJebEGOHgNahhDk1PI7/o=");
_c = QueryProvider;
function _QueryProviderUseState() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$modern$2f$queryClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryClient"]({
        defaultOptions: {
            queries: {
                staleTime: 300000,
                gcTime: 600000,
                retry: 1,
                refetchOnWindowFocus: false
            }
        }
    });
}
var _c;
__turbopack_context__.k.register(_c, "QueryProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Desktop_pra%20usar%20dps_6%20-%20Pessoal_RepTrail_web_src_4fbd0c8f._.js.map