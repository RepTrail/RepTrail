(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__840e2a92._.css",
  "static/chunks/f115e_6 - Pessoal_RepTrail_web_src_components_feature_pwa-install-prompt_tsx_32734be2._.js",
  "static/chunks/Desktop_pra usar dps_6 - Pessoal_RepTrail_web_src_4fbd0c8f._.js",
  "static/chunks/2c0c8_tailwind-merge_dist_bundle-mjs_mjs_566ee777._.js",
  "static/chunks/2c0c8_@supabase_auth-js_dist_module_8704a0c6._.js",
  "static/chunks/2c0c8_1d3dbd70._.js"
],
    source: "dynamic"
});
