(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_46032f64._.js",
  "static/chunks/2c0c8_next_dist_compiled_react-dom_5f54f435._.js",
  "static/chunks/2c0c8_next_dist_compiled_react-server-dom-turbopack_d04ee25f._.js",
  "static/chunks/2c0c8_next_dist_compiled_next-devtools_index_1dbab5ed.js",
  "static/chunks/2c0c8_next_dist_compiled_322a3a2f._.js",
  "static/chunks/2c0c8_next_dist_client_03d046a8._.js",
  "static/chunks/2c0c8_next_dist_a3614c21._.js",
  "static/chunks/2c0c8_@swc_helpers_cjs_2df5f1e9._.js"
],
    source: "entry"
});
