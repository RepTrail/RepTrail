(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Dialog",
    ()=>Dialog,
    "DialogClose",
    ()=>DialogClose,
    "DialogContent",
    ()=>DialogContent,
    "DialogDescription",
    ()=>DialogDescription,
    "DialogFooter",
    ()=>DialogFooter,
    "DialogHeader",
    ()=>DialogHeader,
    "DialogOverlay",
    ()=>DialogOverlay,
    "DialogPortal",
    ()=>DialogPortal,
    "DialogTitle",
    ()=>DialogTitle,
    "DialogTrigger",
    ()=>DialogTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/x.js [app-client] (ecmascript) <export default as XIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-client] (ecmascript) <export * as Dialog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/lib/utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/button.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
function Dialog(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let props;
    if ($[1] !== t0) {
        ({ ...props } = t0);
        $[1] = t0;
        $[2] = props;
    } else {
        props = $[2];
    }
    let t1;
    if ($[3] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Root, {
            "data-slot": "dialog",
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 29,
            columnNumber: 10
        }, this);
        $[3] = props;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    return t1;
}
_c = Dialog;
function DialogTrigger(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let props;
    if ($[1] !== t0) {
        ({ ...props } = t0);
        $[1] = t0;
        $[2] = props;
    } else {
        props = $[2];
    }
    let t1;
    if ($[3] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Trigger, {
            "data-slot": "dialog-trigger",
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 57,
            columnNumber: 10
        }, this);
        $[3] = props;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    return t1;
}
_c1 = DialogTrigger;
function DialogPortal(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let props;
    if ($[1] !== t0) {
        ({ ...props } = t0);
        $[1] = t0;
        $[2] = props;
    } else {
        props = $[2];
    }
    let t1;
    if ($[3] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Portal, {
            "data-slot": "dialog-portal",
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 85,
            columnNumber: 10
        }, this);
        $[3] = props;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    return t1;
}
_c2 = DialogPortal;
function DialogClose(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let props;
    if ($[1] !== t0) {
        ({ ...props } = t0);
        $[1] = t0;
        $[2] = props;
    } else {
        props = $[2];
    }
    let t1;
    if ($[3] !== props) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Close, {
            "data-slot": "dialog-close",
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 113,
            columnNumber: 10
        }, this);
        $[3] = props;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    return t1;
}
_c3 = DialogClose;
function DialogOverlay(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let className;
    let props;
    if ($[1] !== t0) {
        ({ className, ...props } = t0);
        $[1] = t0;
        $[2] = className;
        $[3] = props;
    } else {
        className = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== className) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("fixed inset-0 z-50 bg-black/50", className);
        $[4] = className;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== props || $[7] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Overlay, {
            "data-slot": "dialog-overlay",
            className: t1,
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 153,
            columnNumber: 10
        }, this);
        $[6] = props;
        $[7] = t1;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    return t2;
}
_c4 = DialogOverlay;
function DialogContent(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(16);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 16; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let children;
    let className;
    let props;
    let t1;
    if ($[1] !== t0) {
        ({ className, children, showCloseButton: t1, ...props } = t0);
        $[1] = t0;
        $[2] = children;
        $[3] = className;
        $[4] = props;
        $[5] = t1;
    } else {
        children = $[2];
        className = $[3];
        props = $[4];
        t1 = $[5];
    }
    const showCloseButton = t1 === undefined ? true : t1;
    let t2;
    if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogOverlay, {}, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 195,
            columnNumber: 10
        }, this);
        $[6] = t2;
    } else {
        t2 = $[6];
    }
    let t3;
    if ($[7] !== className) {
        t3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-background fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-4 rounded-lg border p-6 shadow-lg outline-none sm:max-w-lg", className);
        $[7] = className;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    let t4;
    if ($[9] !== showCloseButton) {
        t4 = showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Close, {
            "data-slot": "dialog-close",
            className: "absolute top-6 right-6 p-4 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-500 hover:text-white hover:bg-zinc-800 outline-none focus:ring-2 focus:ring-zinc-700 disabled:pointer-events-none group transition-colors cursor-pointer z-[60] pointer-events-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XIcon$3e$__["XIcon"], {
                    className: "w-5 h-5"
                }, void 0, false, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
                    lineNumber: 210,
                    columnNumber: 352
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "sr-only",
                    children: "Close"
                }, void 0, false, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
                    lineNumber: 210,
                    columnNumber: 381
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 210,
            columnNumber: 29
        }, this);
        $[9] = showCloseButton;
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    let t5;
    if ($[11] !== children || $[12] !== props || $[13] !== t3 || $[14] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DialogPortal, {
            "data-slot": "dialog-portal",
            children: [
                t2,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Content, {
                    "data-slot": "dialog-content",
                    className: t3,
                    ...props,
                    children: [
                        children,
                        t4
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
                    lineNumber: 218,
                    columnNumber: 54
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 218,
            columnNumber: 10
        }, this);
        $[11] = children;
        $[12] = props;
        $[13] = t3;
        $[14] = t4;
        $[15] = t5;
    } else {
        t5 = $[15];
    }
    return t5;
}
_c5 = DialogContent;
function DialogHeader(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let className;
    let props;
    if ($[1] !== t0) {
        ({ className, ...props } = t0);
        $[1] = t0;
        $[2] = className;
        $[3] = props;
    } else {
        className = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== className) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col gap-2 text-center sm:text-left", className);
        $[4] = className;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== props || $[7] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-slot": "dialog-header",
            className: t1,
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 261,
            columnNumber: 10
        }, this);
        $[6] = props;
        $[7] = t1;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    return t2;
}
_c6 = DialogHeader;
function DialogFooter(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(15);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 15; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let children;
    let className;
    let props;
    let t1;
    if ($[1] !== t0) {
        ({ className, showCloseButton: t1, children, ...props } = t0);
        $[1] = t0;
        $[2] = children;
        $[3] = className;
        $[4] = props;
        $[5] = t1;
    } else {
        children = $[2];
        className = $[3];
        props = $[4];
        t1 = $[5];
    }
    const showCloseButton = t1 === undefined ? false : t1;
    let t2;
    if ($[6] !== className) {
        t2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className);
        $[6] = className;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    let t3;
    if ($[8] !== showCloseButton) {
        t3 = showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Close, {
            asChild: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                variant: "outline",
                children: "Close"
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
                lineNumber: 311,
                columnNumber: 67
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 311,
            columnNumber: 29
        }, this);
        $[8] = showCloseButton;
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    let t4;
    if ($[10] !== children || $[11] !== props || $[12] !== t2 || $[13] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            "data-slot": "dialog-footer",
            className: t2,
            ...props,
            children: [
                children,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 319,
            columnNumber: 10
        }, this);
        $[10] = children;
        $[11] = props;
        $[12] = t2;
        $[13] = t3;
        $[14] = t4;
    } else {
        t4 = $[14];
    }
    return t4;
}
_c7 = DialogFooter;
function DialogTitle(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let className;
    let props;
    if ($[1] !== t0) {
        ({ className, ...props } = t0);
        $[1] = t0;
        $[2] = className;
        $[3] = props;
    } else {
        className = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== className) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-lg leading-none font-semibold", className);
        $[4] = className;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== props || $[7] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Title, {
            "data-slot": "dialog-title",
            className: t1,
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 362,
            columnNumber: 10
        }, this);
        $[6] = props;
        $[7] = t1;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    return t2;
}
_c8 = DialogTitle;
function DialogDescription(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(9);
    if ($[0] !== "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236") {
        for(let $i = 0; $i < 9; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "f289b1a58eb94182d4e0507ab8433ac5dd7325b5774d7ab6932477325c611236";
    }
    let className;
    let props;
    if ($[1] !== t0) {
        ({ className, ...props } = t0);
        $[1] = t0;
        $[2] = className;
        $[3] = props;
    } else {
        className = $[2];
        props = $[3];
    }
    let t1;
    if ($[4] !== className) {
        t1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$lib$2f$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-muted-foreground text-sm", className);
        $[4] = className;
        $[5] = t1;
    } else {
        t1 = $[5];
    }
    let t2;
    if ($[6] !== props || $[7] !== t1) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Dialog$3e$__["Dialog"].Description, {
            "data-slot": "dialog-description",
            className: t1,
            ...props
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx",
            lineNumber: 403,
            columnNumber: 10
        }, this);
        $[6] = props;
        $[7] = t1;
        $[8] = t2;
    } else {
        t2 = $[8];
    }
    return t2;
}
_c9 = DialogDescription;
;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9;
__turbopack_context__.k.register(_c, "Dialog");
__turbopack_context__.k.register(_c1, "DialogTrigger");
__turbopack_context__.k.register(_c2, "DialogPortal");
__turbopack_context__.k.register(_c3, "DialogClose");
__turbopack_context__.k.register(_c4, "DialogOverlay");
__turbopack_context__.k.register(_c5, "DialogContent");
__turbopack_context__.k.register(_c6, "DialogHeader");
__turbopack_context__.k.register(_c7, "DialogFooter");
__turbopack_context__.k.register(_c8, "DialogTitle");
__turbopack_context__.k.register(_c9, "DialogDescription");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PWAInstallPrompt",
    ()=>PWAInstallPrompt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/dialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/download.js [app-client] (ecmascript) <export default as Download>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/smartphone.js [app-client] (ecmascript) <export default as Smartphone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Share$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/share.js [app-client] (ecmascript) <export default as Share>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusSquare$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/square-plus.js [app-client] (ecmascript) <export default as PlusSquare>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/lucide-react/dist/esm/icons/circle-check.js [app-client] (ecmascript) <export default as CheckCircle2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function PWAInstallPrompt() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(26);
    if ($[0] !== "46e1d8e8930063454f4681d87c65ea2e72041f052e4f605d8fc4859e4c657702") {
        for(let $i = 0; $i < 26; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "46e1d8e8930063454f4681d87c65ea2e72041f052e4f605d8fc4859e4c657702";
    }
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const [showPrompt, setShowPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deferredPrompt, setDeferredPrompt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isIOS, setIsIOS] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isStandalone, setIsStandalone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t0;
    if ($[1] !== pathname) {
        t0 = pathname?.startsWith("/dashboard/student");
        $[1] = pathname;
        $[2] = t0;
    } else {
        t0 = $[2];
    }
    const isStudentPath = t0;
    let t1;
    if ($[3] !== isStudentPath) {
        t1 = ({
            "PWAInstallPrompt[useEffect()]": ()=>{
                if (!isStudentPath) {
                    return;
                }
                const isStandaloneMode = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone || document.referrer.includes("android-app://");
                setIsStandalone(isStandaloneMode);
                const userAgent = window.navigator.userAgent.toLowerCase();
                const ios = /iphone|ipad|ipod/.test(userAgent);
                setIsIOS(ios);
                const handleBeforeInstallPrompt = {
                    "PWAInstallPrompt[useEffect() > handleBeforeInstallPrompt]": (e)=>{
                        e.preventDefault();
                        setDeferredPrompt(e);
                        if (!isStandaloneMode && !localStorage.getItem("pwa_prompt_shown_v1")) {
                            setShowPrompt(true);
                        }
                    }
                }["PWAInstallPrompt[useEffect() > handleBeforeInstallPrompt]"];
                window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
                const handleManualTrigger = {
                    "PWAInstallPrompt[useEffect() > handleManualTrigger]": ()=>{
                        setShowPrompt(true);
                    }
                }["PWAInstallPrompt[useEffect() > handleManualTrigger]"];
                window.addEventListener("open-pwa-prompt", handleManualTrigger);
                if (ios && !isStandaloneMode && !localStorage.getItem("pwa_prompt_shown_v1")) {
                    const timer = setTimeout({
                        "PWAInstallPrompt[useEffect() > setTimeout()]": ()=>{
                            setShowPrompt(true);
                        }
                    }["PWAInstallPrompt[useEffect() > setTimeout()]"], 3000);
                    return ()=>clearTimeout(timer);
                }
                return ()=>{
                    window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
                    window.removeEventListener("open-pwa-prompt", handleManualTrigger);
                };
            }
        })["PWAInstallPrompt[useEffect()]"];
        $[3] = isStudentPath;
        $[4] = t1;
    } else {
        t1 = $[4];
    }
    let t2;
    if ($[5] !== isStandalone || $[6] !== isStudentPath) {
        t2 = [
            isStandalone,
            isStudentPath
        ];
        $[5] = isStandalone;
        $[6] = isStudentPath;
        $[7] = t2;
    } else {
        t2 = $[7];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[8] !== deferredPrompt) {
        t3 = ({
            "PWAInstallPrompt[handleInstallClick]": async ()=>{
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    const { outcome } = await deferredPrompt.userChoice;
                    if (outcome === "accepted") {
                        console.log("User accepted the install prompt");
                    }
                    setDeferredPrompt(null);
                    setShowPrompt(false);
                }
                localStorage.setItem("pwa_prompt_shown_v1", "true");
            }
        })["PWAInstallPrompt[handleInstallClick]"];
        $[8] = deferredPrompt;
        $[9] = t3;
    } else {
        t3 = $[9];
    }
    const handleInstallClick = t3;
    let t4;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = ({
            "PWAInstallPrompt[closePrompt]": ()=>{
                setShowPrompt(false);
                localStorage.setItem("pwa_prompt_shown_v1", "true");
            }
        })["PWAInstallPrompt[closePrompt]"];
        $[10] = t4;
    } else {
        t4 = $[10];
    }
    const closePrompt = t4;
    if (!isStudentPath || isStandalone || !showPrompt) {
        return null;
    }
    let t5;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "sr-only",
            children: "Fechar"
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 130,
            columnNumber: 10
        }, this);
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-6 right-6 md:top-8 md:right-8 z-50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogClose"], {
                asChild: true,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                    variant: "ghost",
                    className: "h-10 w-10 md:h-12 md:w-12 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-400 hover:text-white transition-all backdrop-blur-md",
                    children: [
                        t5,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            width: "20",
                            height: "20",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            stroke: "currentColor",
                            strokeWidth: "3",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            className: "md:w-6 md:h-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "M18 6 6 18"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 137,
                                    columnNumber: 501
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    d: "m6 6 12 12"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 137,
                                    columnNumber: 524
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 137,
                            columnNumber: 297
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                    lineNumber: 137,
                    columnNumber: 103
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                lineNumber: 137,
                columnNumber: 75
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 137,
            columnNumber: 10
        }, this);
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-0 right-0 p-12 opacity-5 pointer-events-none",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$smartphone$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Smartphone$3e$__["Smartphone"], {
                className: "w-48 h-48 text-emerald-500"
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                lineNumber: 144,
                columnNumber: 85
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 144,
            columnNumber: 10
        }, this);
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-20 h-20 bg-emerald-500/10 border border-emerald-500/20 rounded-[2rem] flex items-center justify-center shadow-xl shadow-emerald-500/10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                className: "w-10 h-10 text-emerald-500"
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                lineNumber: 151,
                columnNumber: 164
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 151,
            columnNumber: 10
        }, this);
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogHeader"], {
            className: "relative z-10 text-left space-y-6",
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogTitle"], {
                            className: "text-3xl md:text-5xl font-black text-white italic uppercase tracking-tighter leading-tight",
                            children: [
                                "RepTrail no seu ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-emerald-500",
                                    children: "Celular"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 158,
                                    columnNumber: 211
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 158,
                            columnNumber: 79
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogDescription"], {
                            className: "text-zinc-500 font-bold uppercase tracking-widest text-[10px] mt-4",
                            children: "Performance máxima em tela cheia"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 158,
                            columnNumber: 274
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                    lineNumber: 158,
                    columnNumber: 74
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 158,
            columnNumber: 10
        }, this);
        $[15] = t9;
    } else {
        t9 = $[15];
    }
    let t10;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/20 group-hover:scale-110 transition-transform shrink-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                className: "w-5 h-5 md:w-6 md:h-6 text-emerald-500"
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                lineNumber: 165,
                columnNumber: 212
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 165,
            columnNumber: 11
        }, this);
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-4 md:gap-5 p-4 md:p-6 bg-white/5 rounded-[1.5rem] md:rounded-[2rem] border border-white/5 backdrop-blur-sm group hover:bg-white/10 transition-colors",
            children: [
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs md:text-sm font-black text-white uppercase italic tracking-wider",
                            children: "Sem Barras"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 172,
                            columnNumber: 231
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-[9px] md:text-[10px] text-zinc-500 font-bold uppercase tracking-widest",
                            children: "Navegação Full Screen"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 172,
                            columnNumber: 333
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                    lineNumber: 172,
                    columnNumber: 204
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 172,
            columnNumber: 11
        }, this);
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/20 group-hover:scale-110 transition-transform shrink-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle2$3e$__["CheckCircle2"], {
                className: "w-5 h-5 md:w-6 md:h-6 text-emerald-500"
            }, void 0, false, {
                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                lineNumber: 179,
                columnNumber: 212
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 179,
            columnNumber: 11
        }, this);
        $[18] = t12;
    } else {
        t12 = $[18];
    }
    let t13;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid gap-4 pb-4",
            children: [
                t11,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4 md:gap-5 p-4 md:p-6 bg-white/5 rounded-[1.5rem] md:rounded-[2rem] border border-white/5 backdrop-blur-sm group hover:bg-white/10 transition-colors",
                    children: [
                        t12,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs md:text-sm font-black text-white uppercase italic tracking-wider",
                                    children: "Acesso Rápido"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 186,
                                    columnNumber: 269
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[9px] md:text-[10px] text-zinc-500 font-bold uppercase tracking-widest",
                                    children: "Atalho na Home"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 186,
                                    columnNumber: 374
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 186,
                            columnNumber: 242
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                    lineNumber: 186,
                    columnNumber: 49
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[19] = t13;
    } else {
        t13 = $[19];
    }
    let t14;
    if ($[20] !== handleInstallClick || $[21] !== isIOS) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DialogContent"], {
            className: "bg-zinc-950/95 border-zinc-900 text-white max-w-lg rounded-[2.5rem] md:rounded-[3.5rem] backdrop-blur-3xl p-0 overflow-hidden shadow-[0_0_100px_rgba(0,0,0,1)] gap-0 [&>button]:hidden max-h-[90dvh] flex flex-col",
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative p-6 pt-16 md:p-10 md:pt-20 space-y-8 overflow-y-auto flex-1 scrollbar-thin scrollbar-thumb-white/10 scrollbar-track-transparent",
                    children: [
                        t7,
                        t9,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-8 relative z-10",
                            children: [
                                t13,
                                isIOS ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-emerald-500/10 border border-emerald-500/20 p-6 md:p-8 rounded-[2rem] md:rounded-[2.5rem] space-y-4 md:space-y-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-[10px] md:text-xs font-black text-emerald-500 uppercase tracking-[0.3em] flex items-center gap-2 mb-2 md:mb-4",
                                            children: "Configuração iOS:"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                            lineNumber: 193,
                                            columnNumber: 603
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                                            className: "space-y-3 md:space-y-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "flex items-center gap-3 md:gap-4 text-white text-[10px] md:text-xs font-black uppercase italic tracking-widest",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl bg-zinc-950 border border-zinc-900 flex items-center justify-center shrink-0 shadow-2xl",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$share$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Share$3e$__["Share"], {
                                                                className: "w-4 h-4 md:w-5 md:h-5 text-emerald-500"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                                lineNumber: 193,
                                                                columnNumber: 1074
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                            lineNumber: 193,
                                                            columnNumber: 920
                                                        }, this),
                                                        "1. Clique em Compartilhar"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                    lineNumber: 193,
                                                    columnNumber: 793
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    className: "flex items-center gap-3 md:gap-4 text-white text-[10px] md:text-xs font-black uppercase italic tracking-widest",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "w-8 h-8 md:w-10 md:h-10 rounded-lg md:rounded-xl bg-zinc-950 border border-zinc-900 flex items-center justify-center shrink-0 shadow-2xl",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$plus$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusSquare$3e$__["PlusSquare"], {
                                                                className: "w-4 h-4 md:w-5 md:h-5 text-emerald-500"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                                lineNumber: 193,
                                                                columnNumber: 1451
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                            lineNumber: 193,
                                                            columnNumber: 1297
                                                        }, this),
                                                        '2. "Tela de Início"'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                    lineNumber: 193,
                                                    columnNumber: 1170
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                            lineNumber: 193,
                                            columnNumber: 754
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: closePrompt,
                                            className: "w-full mt-4 md:mt-6 h-12 md:h-14 rounded-xl md:rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black uppercase italic tracking-widest shadow-xl shadow-emerald-500/20 text-xs md:text-sm",
                                            children: "Entendi"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                            lineNumber: 193,
                                            columnNumber: 1551
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 193,
                                    columnNumber: 470
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: handleInstallClick,
                                            className: "h-14 md:h-16 rounded-2xl md:rounded-[2rem] bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-black uppercase italic tracking-widest transition-all shadow-2xl shadow-emerald-500/30 text-base md:text-lg group",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$download$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Download$3e$__["Download"], {
                                                    className: "w-5 h-5 mr-3 group-hover:bounce"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                                    lineNumber: 193,
                                                    columnNumber: 2120
                                                }, this),
                                                "Instalar Agora"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                            lineNumber: 193,
                                            columnNumber: 1859
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            variant: "ghost",
                                            onClick: closePrompt,
                                            className: "h-12 text-zinc-600 hover:text-white font-black uppercase italic tracking-widest text-[10px]",
                                            children: "Agora não"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                            lineNumber: 193,
                                            columnNumber: 2199
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                                    lineNumber: 193,
                                    columnNumber: 1822
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                            lineNumber: 193,
                            columnNumber: 415
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
                    lineNumber: 193,
                    columnNumber: 253
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 193,
            columnNumber: 11
        }, this);
        $[20] = handleInstallClick;
        $[21] = isIOS;
        $[22] = t14;
    } else {
        t14 = $[22];
    }
    let t15;
    if ($[23] !== showPrompt || $[24] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$src$2f$components$2f$ui$2f$dialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Dialog"], {
            open: showPrompt,
            onOpenChange: setShowPrompt,
            children: t14
        }, void 0, false, {
            fileName: "[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[23] = showPrompt;
        $[24] = t14;
        $[25] = t15;
    } else {
        t15 = $[25];
    }
    return t15;
}
_s(PWAInstallPrompt, "93uJ2Eun0RoiXOELpwd1/IWz99Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$pra__usar__dps$2f$6__$2d$__Pessoal$2f$RepTrail$2f$web$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = PWAInstallPrompt;
var _c;
__turbopack_context__.k.register(_c, "PWAInstallPrompt");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/pra usar dps/6 - Pessoal/RepTrail/web/src/components/feature/pwa-install-prompt.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=Desktop_pra%20usar%20dps_6%20-%20Pessoal_RepTrail_web_src_components_5adff30a._.js.map